<?php
include('include/config.php');
include('include/function.php');
include('include/class/database.class.php');
include('include/class/table.class.php');
	
date_default_timezone_set('PRC');
	
header('Content-Type:text/html;charset=utf-8');
header('Cache-Control:private');
	
session_start();
	
//
?>