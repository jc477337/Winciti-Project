{*<?php exit();?>*}
{foreach from=$best_goo_cat name=best_goo_cat item=cat}
<div class="block img_list">
	<div class="head"><span>{$cat.cat_name}</span><a href="{url channel='goods' cat=$cat.cat_id}">More&gt;&gt;</a></div>
	<div class="main">
		{foreach from=$goods_list[$cat.cat_id] name=goods_list item=item}
		<div class="unit">
			<div class="img">
				<table>
					<tr>
						<td>
							<a href="{url channel='goods' id=$item.goo_id}" target="_blank"><img src="{$S_ROOT}{$item.goo_x_img}" onload="picresize(this,130,130)"/></a>
						</td>
					</tr>
				</table>
			</div>
			<div class="word">
				<div class="title"><a href="{url channel='goods' id=$item.goo_id}" target="_blank">{$item.goo_title}</a></div>
				<div class="market_price">RRP:<span>${$item.goo_market_price}Aud</span></div>
				<div class="shop_price">Our Price:${$item.goo_shop_price}Aud</div>
			</div>
		</div>
		{/foreach}
		<div class="clear"></div>
	</div>
</div>
{/foreach}
<!--  -->