{*<?php exit();?>*}
<div class="block img_list">
	{include file="module/here.php"}
	<div class="main">
		{foreach from=$search name=search item=item}
		<div class="unit">
			<div class="img">
				<table>
					<tr>
						<td>
							<a href="{url channel='goods' id=$item.goo_id}" target="_blank"><img src="{$S_ROOT}{$item.goo_x_img}" onload="picresize(this,300,300)"/></a>
						</td>
					</tr>
				</table>
			</div>
			<div class="word">
				<div class="title"><a href="{url channel='goods' id=$item.goo_id}" target="_blank">{$item.goo_title}</a></div>
				<div class="market_price">RRP:<span>${$item.goo_market_price}Aud</span></div>
				<div class="shop_price">Our Price:${$item.goo_shop_price}Aud</div>
			</div>
		</div>
		{/foreach}
		<div class="clear"></div>
		{if !$search}<div class="not_found">NO Content</div>{/if}
		{$prefix = 'search/cat-'|cat:$global.cat|cat:'/key-'|cat:$global.key}
		{include file="module/page_link.php" page=$global.page}
	</div>
</div>
<!--  -->
