{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>Out of stock record</span></div>
	<div class="main add_booking">
		<form name="form_add_booking" method="post" action="{url channel='user'}">
			<input name="cmd" type="hidden" value="add_booking"/>
			<input name="goods_id" type="hidden" value="{$global.goods_id}"/>
			<table class="table">
				<tr>
					<td class="l">Product:</td>
					<td class="r">{$goods_title}</td>
				</tr>
				<tr>
					<td class="l">Quantity:</td>
					<td class="r"><input class="text" name="number" type="text" /></td>
				</tr>
				<tr>
					<td class="l">Description:</td>
					<td class="r"><textarea name="text"></textarea></td>
				</tr>
				<tr>
					<td class="l">Contact:</td>
					<td class="r"><input class="text" name="consignee" type="text" value="{$boo_consignee}" /></td>
				</tr>
				<tr>
					<td class="l">E-mail:</td>
					<td class="r"><input class="text" name="email" type="text" value="{$boo_email}" /></td>
				</tr>
				<tr>
					<td class="l">Contact Number:</td>
					<td class="r"><input class="text" name="tel" type="text" value="{$boo_tel}" /></td>
				</tr>
				<tr>
					<td class="bt_row" colspan="2"><input class="button" type="button" onclick="submit_add_booking()" value="Confirm The Change" /></td>
				</tr>
			</table>
		</form>
	</div>
</div>
{literal}
<script language="javascript">
function submit_add_booking()
{
	var str = "";
	if(document.form_add_booking.number.value == ""){str += "Quantity is Required\n";}
	if(document.form_add_booking.text.value == ""){str += "Description is Required\n";}
	if(document.form_add_booking.consignee.value == ""){str += "Contact is Required\n";}
	if(document.form_add_booking.email.value == ""){str += "E-mail is Required\n";}
	if(document.form_add_booking.tel.value == ""){str += "Contact Number is Required\n";}
	if(str != "")
	{
alert(str);
	}else{
		document.form_add_booking.submit();
	}
}
</script>
{/literal}
<!--  -->