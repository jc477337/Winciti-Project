{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>User Info</span></div>
	<div class="main">
		<form name="form_edit_profile" method="post" action="{url channel='user'}">
			<input name="cmd" type="hidden" value="edit_profile"/>
			<table class="table">
				<tr>
					<td class="l">Date of Birth:</td>
					<td class="r">
						<select name="birthday_year">
						<option value="0">Please Select</option>
							{section name=loop loop=100}
							{$val = 1913 + $smarty.section.loop.index + 1}
							<option value="{$val}" {if $val == $use_birthday_year}selected="selected"{/if}>{$val}</option>
							{/section}
						</select>&nbsp;&nbsp;
						<select name="birthday_month">
							<option value="0">Please Select</option>
							{section name=loop loop=12}
							{$val = $smarty.section.loop.index + 1}
							<option value="{$val}" {if $val == $use_birthday_month}selected="selected"{/if}>{$val}</option>
							{/section}
						</select>&nbsp;&nbsp;
						<select name="birthday_day">
							<option value="0">Please Select</option>
							{section name=loop loop=31}
							{$val = $smarty.section.loop.index + 1}
							<option value="{$val}" {if $val == $use_birthday_day}selected="selected"{/if}>{$val}</option>
							{/section}
						</select>
					</td>
				</tr>
				<tr>
					<td class="l">Gender:</td>
					<td class="r">
						<input name="sex" type="radio" value="0" {if $use_sex == 0}checked="checked"{/if} />Secret&nbsp;&nbsp;
						<input name="sex" type="radio" value="1" {if $use_sex == 1}checked="checked"{/if} />Male&nbsp;&nbsp;
						<input name="sex" type="radio" value="2" {if $use_sex == 2}checked="checked"{/if} />Female
					</td>
				</tr>
				<tr>
					<td class="l">Name:</td>
					<td class="r"><input class="text" name="real_name" type="text" value="{$use_real_name}" /></td>
				</tr>
				<tr>
					<td class="l">Email:</td>
					<td class="r"><input class="text" name="email" type="text" value="{$use_email}" /></td>
				</tr>				
				<tr>
					<td class="l">Phone:</td>
					<td class="r"><input class="text" name="tel" type="text" value="{$use_tel}" /></td>
				</tr>
				<tr>
					<td class="l">Mobile:</td>
					<td class="r"><input class="text" name="phone" type="text" value="{$use_phone}" /></td>
				</tr>
				<tr>
					<td class="l">Address:</td>
					<td class="r"><input class="text" name="address" type="text" value="{$use_address}" /></td>
				</tr>
				<tr>
					<td class="l">Secret Question:</td>
					<td class="r">
						<select name="question">
							<option value="0">Secret Question</option>
							<option value="friend_birthday" {if $use_question == 'friend_birthday'}selected="selected"{/if}>What is your best firend Birthday?</option>
							<option value="old_address" {if $use_question == 'old_address'}selected="selected"{/if}>where is your home town?</option>
							<option value="motto" {if $use_question == 'motto'}selected="selected"{/if}>A xzxxxx</option>
							<option value="favorite_movie" {if $use_question == 'favorite_movie'}selected="selected"{/if}>Film</option>
							<option value="favorite_song" {if $use_question == 'favorite_song'}selected="selected"{/if}>Sone？</option>
							<option value="favorite_food" {if $use_question == 'favorite_food'}selected="selected"{/if}>Food？</option>
							<option value="interest" {if $use_question == 'interest'}selected="selected"{/if}>Hobby？</option>
							<option value="favorite_novel" {if $use_question == 'favorite_novel'}selected="selected"{/if}>Book？</option>
							<option value="favorite_equipe" {if $use_question == 'favorite_equipe'}selected="selected"{/if}>Sport？</option>
						</select>
					</td>
				</tr>
				<tr>
					<td class="l">Secret Answer:</td>
					<td class="r"><input class="text" name="answer" type="text" value="{$use_answer}" /></td>
				</tr>
				<tr>
					<td colspan="2" class="bt_row"><input class="button" type="button" onclick="submit_edit_profile()" value="Confirm Change" /></td>
				</tr>
			</table>
		</form>
		<div class="space"></div>
		<form name="form_edit_pwd" method="post" action="{url channel='user'}">
			<input name="cmd" type="hidden" value="edit_pwd"/>
			<table class="table">
				<tr>
					<td class="l">Old Password:</td>
					<td class="r"><input class="text" name="old_pwd" type="password" /></td>
				</tr>
				<tr>
					<td class="l">New Password:</td>
					<td class="r"><input class="text" name="new_pwd" type="password" /></td>
				</tr>
				<tr>
					<td class="l">Confirm Password:</td>
					<td class="r"><input class="text" name="re_pwd" type="password" /></td>
				</tr>
				<tr>
					<td colspan="2" class="bt_row"><input class="button" type="button" onclick="submit_edit_pwd()" value="Confirm Change" /></td>
				</tr>
			</table>
		</form>
	</div>
</div>
{literal}
<script language="javascript">
function submit_edit_profile()
{
	var str = "";
	if(document.form_edit_profile.real_name.value == ""){str += "Name is Required\n";}
	if(document.form_edit_profile.email.value == ""){str += "E-mail is Required\n";}
	if(document.form_edit_profile.qq.value == ""){str += "QQ is Required\n";}
	if(document.form_edit_profile.tel.value == ""){str += "Phoine is Required\n";}
	if(document.form_edit_profile.address.value == ""){str += "Address is Required\n";}
	if(str != "")
	{
		alert(str);
	}else{
		document.form_edit_profile.submit();
	}
}
function submit_edit_pwd()
{
	var str = "";
	var old_pwd = document.form_edit_pwd.old_pwd.value;
	var new_pwd = document.form_edit_pwd.new_pwd.value;
	var re_pwd = document.form_edit_pwd.re_pwd.value;
	if(old_pwd.length < 6){str += "Old password can not be less than 6 characters\n";}
	else if(old_pwd.length > 15){str += "Old password can not be more than 15 characters\n";}
	if(new_pwd.length < 6){str += "New password can not be less than 6 characters\n";}
	else if(new_pwd.length > 15){str += "New password can not be more than 15 characters\n";}
	if(new_pwd != re_pwd){str += "Enter the password twice inconsistent\n";}
	if(str != "")
	{
		alert(str);
	}else{
		document.form_edit_pwd.submit();
	}
}
</script>
{/literal}
<!--  -->