{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>Out of stock record</span></div>
	<div class="main">
		<table class="table">
			<tr>
				<td class="l">Product:</td>
				<td class="r">{$booking.goods_title}</td>
			</tr>
			<tr>
				<td class="l">Order Quantity:</td>
				<td class="r">{$booking.boo_number}</td>
			</tr>
			<tr>
				<td class="l">Description:</td>
				<td class="r">{$booking.boo_text}</td>
			</tr>
			<tr>
				<td class="l">Contact:</td>
				<td class="r">{$booking.boo_consignee}</td>
			</tr>
			<tr>
				<td class="l">E-mail:</td>
				<td class="r">{$booking.boo_email}</td>
			</tr>
			<tr>
				<td class="l">Contact Number:</td>
				<td class="r">{$booking.boo_tel}</td>
			</tr>
			<tr>
				<td class="l">Order Time:</td>
				<td class="r">{$booking.boo_add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
			</tr>
			<tr>
				<td class="l">Access Comment:</td>
				<td class="r">{$booking.boo_note}</td>
			</tr>
			<tr>
				<td colspan="2">
					<div class="bt_row">
						<input class="button" type="button" onclick="go_back()" value="Return" />
					</div>
				</td>
			</tr>
		</table>
	</div>
</div>
<!--  -->