{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>My Collect</span></div>
	<div class="main">
		<table class="table">
			<tr class="c">
				<td width="300px"><b>Product</b></td>
				<td><b>RRP</b></td>
				<td><b>Our Price</b></td>
				<td width="150px"><b>Apply<!--操作--></b></td>
			</tr>
			{foreach from=$collection name=collection item=item}
			<tr class="c">
				<td>{$item.goo_title}</td>
				<td>${$item.goo_market_price}Aud</td>
				<td>${$item.goo_shop_price}Aud</td>
				<td>
					<a onclick="add_to_cart({$item.goo_id})">[Add to Cart]</a>&nbsp;&nbsp;
					<a onclick="del_collection({$item.col_id})">[Delete]</a>
				</td>
			</tr>
			{/foreach}
		</table>
	</div>
</div>
{literal}
<script language="javascript">
function add_to_cart(id)
{
	ajax("post","?/deal/","cmd=add_to_cart&id=" + id + "&buy_num=1",
	function(data)
	{
		if(data == 1)
		{
			document.location.href = "?/flow/";
		}else if(data == 2){
			alert("Sorry, the Product is out of stock.\n Would you want to order some？");
			document.location.href = "?/user/mod-booking_add/goods_id-" + id + "/";
		}
	});
}
function del_collection(id)
{
	if(confirm("Are you sure you want to delete the selected item from your Collect?"))
	{
		ajax("post","index.php?/user/","cmd=del_collection&id=" + id,
		function(data)
		{
			if(data == 1)
			{
				document.location.replace(document.location.href);
			}
		});
	}
}
</script>
{/literal}
<!--  -->