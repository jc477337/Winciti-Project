{*<?php exit();?>*}
<div class="block" id="reg_login">
	<div class="head"><span>Register</span></div>
	<div class="main">
		<form name="form_register" method="post" action="{url channel='info'}">
			<input name="cmd" type="hidden" value="register"/>
			<table>
				<tr>
					<td class="l">User Name:</td>
					<td class="r"><input class="text" name="username" type="text" onkeyup="check_register('username',this.value)" /><span id="check_username"></span></td>
				</tr>
				<tr>
					<td class="l">Password:</td>
					<td class="r"><input class="text" name="password" type="password" onkeyup="check_register('password',this.value)" /><span id="check_password"></span></td>
				</tr>
				<tr>
					<td class="l">Confirm Password:</td>
					<td class="r"><input class="text" name="re_password" type="password" onkeyup="check_register('re_password',this.value)" /><span id="check_re_password"></span></td>
				</tr>
				<tr>
					<td class="l">Name:</td>
					<td class="r"><input class="text" name="real_name" type="text" /></td>
				</tr>
				<tr>
					<td class="l">E-mail:</td>
					<td class="r"><input class="text" name="email" type="text" /></td>
				</tr>				
				<tr>
					<td class="l">Phone:</td>
					<td class="r"><input class="text" name="tel" type="text" /></td>
				</tr>
				<tr>
					<td class="l">Address:</td>
					<td class="r"><input class="text" name="address" type="text" /></td>
				</tr>
				<tr>
					<td class="l"></td>
					<td class="r"><input name="agreement" type="checkbox" checked="checked" value="1" />I have read and accepted<a onclick="show_box('user_agreement',700,300);">User Agreement</a></td>
				</tr>
				<tr>
					<td class="l"></td>
					<td class="r"><input type="button" value="Post" onclick="submit_register()" /></td>
				</tr>
			</table>
		</form>
	</div>
</div>
<!-------------------------- BOX -------------------------->
<div class="alert" id="user_agreement">
	<div class="head">
		<div class="title">User Agreement</div>
		<div class="close" onclick="hide_box('user_agreement')">Close</div>
	</div>
	<div class="agr_main">
		{$user_agreement}
	</div>
</div>
<!-------------------------- BOX -------------------------->
{literal}
<script language="javascript">
function check_register(name,val)
{
	switch(name)
	{
		case "username":
		if(val.length < 6)
		{
			document.getElementById("check_username").innerHTML = "password can not be less than 6 characters";
		}else if(val.length > 15){
			document.getElementById("check_username").innerHTML = "password can not be more than 15 characters";
		}else{
			ajax("post","?/deal/","cmd=check_username&val=" + val,
			function(data)
			{
				if(data == 1)
				{
					document.getElementById("check_username").innerHTML = "Sorry，The User is already existed";
				}else{
					document.getElementById("check_username").innerHTML = "This User Name is Free";
				}
			});
		}
		break;
		case "password":
		if(val.length < 6)
		{
			document.getElementById("check_password").innerHTML = "password can not be less than 6 characters";
		}else if(val.length > 15){
			document.getElementById("check_password").innerHTML = "password can not be more than 15 characters";
		}else{
			document.getElementById("check_password").innerHTML = "This Password is Fine";
		}
		break;
		case "re_password":
		var password = document.form_register.password.value;
		if(val != password)
		{
			document.getElementById("check_re_password").innerHTML = "Enter the password twice inconsistent";
		}else{
			document.getElementById("check_re_password").innerHTML = "This Password is Fine";
		}
		break;
	}
}
function submit_register()
{
	var str = "";
	if(document.form_register.username.value == ""){str += "User Name is Required\n";}
	if(document.form_register.password.value == ""){str += "Password is Required\n";}
	if(document.form_register.re_password.value == ""){str += "Confirm Password is Required\n";}
	if(document.form_register.real_name.value == ""){str += "Name is Required\n";}
	if(document.form_register.email.value == ""){str += "E-mail is Required\n";}
	if(document.form_register.tel.value == ""){str += "Phone is Required\n";}
	if(document.form_register.address.value == ""){str += "Address is Required\n";}
	if(document.form_register.agreement.checked == false){str += "You must agree to the user agreement to register\n";}
	if(str != "")
	{
		alert(str);
	}else{
		document.form_register.submit();
	}
}
</script>
{/literal}