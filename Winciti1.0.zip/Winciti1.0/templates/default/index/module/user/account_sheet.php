{*<?php exit();?>*}
<div class="block">
	<div class="head"><span><!--在线充值-->Online recharge</span></div>
	<div class="main">
		<form id="form_pay" method="post" action="{url channel='pay' dir='chinabank' file='send'}" target="_blank">
			<table class="table">
				<tr>
					<td class="l"><!--充值金额-->Recharge amount:</td>
					<td><input class="text" name="v_amount" type="text" value="" />&nbsp;<!--澳币-->Aud</td>
				</tr>
				<tr>
					<td class="l">Comment<!--备注-->:</td>
					<td><input class="text" name="remark1" type="text" value="" /></td>
				</tr>
				<tr><!---->
					<td colspan="2">
						<div class="bt_row">
							<input class="button" type="submit" value="Post" />
						</div>
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>
<div class="block">
	<div class="head"><span><!--财务记录-->Financial records</span></div>
	<div class="main">
		<table class="table sheet">
			<tr class="h"><!-- -->
				<td width="125px"><!--流水号-->Reference Numnber</td>
				<td><!--金额（元）-->Amount(Aud)</td>
				<td width="125px"><!--产生时间-->Created Time</td>
				<td width="125px"><!--完成时间-->Completed Time</td>
				<td width="60px"><!--状态-->Status</td>
			</tr>
			{foreach from=$account name=account item=item}
			<tr>
				<td>{$item.acc_sn}</td>
				<td>{if $item.acc_increase}+{else}-{/if} {$item.acc_amount}</td>
				<td>{$item.acc_add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
				<td>{$item.acc_edit_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
				<td>{$item.status_name}</td>
			</tr>
			{/foreach}
		</table>
		{$prefix = 'user/mod-account_sheet'}
		{include file="module/page_link.php" page=$global.page}		
	</div>
</div>
<!--  -->