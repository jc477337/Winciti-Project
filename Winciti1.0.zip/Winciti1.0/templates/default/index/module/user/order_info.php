{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>Order General Detail</span></div>
	<div class="main">
		<table class="table">
			<tr>
				<td width="100px">Order Number:</td>
				<td width="310px">{$order.ord_sn}</td>
				<td width="100px">Order State:</td>
				<td>
				<div style="float:left;line-height:24px;">{$order.status_name}&nbsp;&nbsp;</div>
				{if $order.ord_status == 0}
					{if $order.payment_code == 'system'}
					<input class="button" type="button" onclick="do_system_pay({$order.ord_id})" value="Payment Complete"<!--Payment Complete--> />
					{elseif $order.payment_code == 'chinabank'}
					<form id="form_pay" method="post" action="{url channel='pay' dir='chinabank' file='send'}" target="_blank">
						<input type="hidden" name="v_oid" value="{$order.ord_sn}" />
						<input type="hidden" name="v_amount" value="{$order.ord_price_total}" />
						<input class="button" type="submit" value="Payment Complete" />
					</form>
					{/if}
				{/if}
				<div class="clear"></div>
				</td>
			</tr>
			<tr>
				<td>Purchaser Name:</td>
				<td>{if $order.ord_user_id}<a href="{url channel='user' mod='user_edit' id=$order.ord_user_id}">{$order.user_name}</a>{else}Anonymous User{/if}</td>
				<td>Order Time:</td>
				<td>{$order.ord_add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
			</tr>
			<tr>
				<td>Payment Method:</td>
				<td>{$order.ord_payment_name}</td>
				<td>Payment Time:</td>
				<td>{$order.ord_pay_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
			</tr>
			<tr>
				<td>Delivery Method:</td>
				<td>{$order.ord_shipping_name}</td>
				<td>Delivery Time:</td>
				<td>{$order.ord_shipping_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
			</tr>
			<tr>
				<td>Tracking Number:</td>
				<td>{$order.ord_express_no}</td>
				<td></td>
				<td></td>
			</tr>
		</table>
	</div>
</div>
<div class="block">
	<div class="head"><span>Collector Detail</span></div>
	<div class="main">
		<table class="table">
			<tr>
				<td width="100px">Collector Name:</td>
				<td>{$order.ord_consignee}</td>
				<td width="100px">E-mail:</td>
				<td>{$order.ord_email}</td>
			</tr>
			<tr>
				<td>Address:</td>
				<td>{$order.ord_address}</td>
				<td>Postcode:</td>
				<td>{$order.ord_zipcode}</td>
			</tr>
			<tr>
				<td>Phone:</td>
				<td>{$order.ord_tel}</td>
				<td>Mobile:</td>
				<td>{$order.ord_mobile}</td>
			</tr>
			<tr>
				<td>Land Mark Building:</td>
				<td>{$order.ord_building}</td>
				<td>Best Delivery time:</td>
				<td>{$order.ord_best_time}</td>
			</tr>
		</table>
	</div>
</div>
<div class="block">
	<div class="head"><span>Product Detail</span></div>
	<div class="main">
		<table class="table sheet">
			<tr class="h">
				<td width="180px">Product Name</td>
				<td>RRP</td>
				<td>Our Price</td>
				<td width="80px">Quantity</td>
				<td>SubTotal</td>
			</tr>
			{foreach from=$goods name=goods item=item}
			<tr class="row">
				<td><a href="{$S_ROOT}{url channel='goods' id=$item.goo_id}" target="_blank">{$item.goo_title}</a></td>
				<td>${$item.goo_market_price}Aud</td>
				<td>${$item.goo_shop_price}Aud</td>
				<td>{$item.number}</td>
				<td>${$item.subtotal}Aud</td>
			</tr>
			{/foreach}
			<tr>
				<td colspan="4"></td>
				<td>Total:${$shop_total}Aud</td>
			</tr>
		</table>
	</div>
</div>
<div class="block">
	<div class="head"><span>Access Detail<!--操作信息--></span></div>
	<div class="main">
		<form id="form_order_note" method="post" action="{url channel=$global.channel}">
			<input name="cmd" type="hidden" value="order_note" />
			<input name="ord_id" type="hidden" value="{$global.id}" />
			<table class="table">
				<tr>
					<td>Access Comment<!--操作备注-->:</td>
					<td><textarea class="textarea" name="ord_note" style="width:600px;height:100px;">{$order.ord_note}</textarea></td>
				</tr>
				<tr>
					<td colspan="2">
						<div class="bt_row">
							<input class="button" type="submit" value="Post" />
							<input class="button" type="button" onclick="go_back()" value="Return" <!--Return-->/>
						</div>
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>
{literal}
<script language="javascript">
function do_system_pay(id)
{
	ajax("post","?/deal/","cmd=do_system_pay&id=" + id,
	function(data)
	{
		if(data == 1)
		{
			alert("Payment Sucdessful");
			document.location.replace(document.location.href);
		}else{
			alert("Payment Failed");
		}
	});
}
</script>
{/literal}