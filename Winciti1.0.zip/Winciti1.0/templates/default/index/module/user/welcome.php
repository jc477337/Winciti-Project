{*<?php exit();?>*}
<div class="block" id="welcome">
	<div class="head"><span class="user_name">{$user_name}</span>&nbsp;&nbsp;<span>Welcome to the user center!</span></div>
	<div class="main">
		Your last login time:{$prev_login}<br />
		Balance:${$user_money}Aud<br />
		You have <b>{$order_count}</b> orders in the last 30 days<br />
	</div>
</div>
<!--  -->