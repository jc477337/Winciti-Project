{*<?php exit();?>*}
<div id="user_menu">
	<ul>
		<li><a href="{url channel='user'}">Welcome</a></li>
		<li><a href="{url channel='user' mod='profile'}">User Info</a></li>
		<li><a href="{url channel='user' mod='order_sheet'}">My Order</a></li>
		<li><a href="{url channel='user' mod='address_list'}">Address</a></li>
		<li><a href="{url channel='user' mod='collection_list'}">My Collect</a></li>
		<li><a href="{url channel='user' mod='message_sheet'}">My Message</a></li>
		<li><a href="{url channel='user' mod='comment_sheet'}">My Comments</a></li>
		<li><a href="{url channel='user' mod='booking_sheet'}">Out of stock record</a></li>
		<li><a href="{url channel='user' mod='account_sheet'}">Online Recharge</a></li>
	</ul>
	<div class="bt_row"><a href="{url channel='user' mod='logout'}">Log out</a></div>
</div>