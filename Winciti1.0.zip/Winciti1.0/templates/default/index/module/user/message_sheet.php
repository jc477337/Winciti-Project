{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>My Message</span></div>
	<div class="main">
		<div class="mes_sheet">
			<ul>
				{foreach from=$message name=message item=item}
				<li>
					<table>
						<tr>
							<td><b>{$item.mes_type}:</b><span>{$item.mes_title}</span>&nbsp;&nbsp;[ {$item.mes_add_time|date_format:"%Y-%m-%d %H:%M:%S"} ]</td>
						</tr>
						<tr>
							<td>{$item.mes_text}</td>
						</tr>
						{if $item.mes_reply}
						<tr>
							<td><div class="reply"><span>Administrator reply:</span>{$item.mes_reply}</div></td>
						</tr>
						{/if}
					</table>
				</li>
				{/foreach}
			</ul>
			{if !$message}<div class="not_found">NO Content</div>{/if}
		</div>
		{$prefix = 'user/mod-message_sheet'}
		{include file="module/page_link.php" page=$global.page}
		<div id="leave_word">
			<form name="form_add_message" method="post" action="{url channel='user'}">
				<input name="cmd" type="hidden" value="add_message"/>
				<table>
					<tr>
						<td class="l">Message Type:</td>
						<td>
							<input name="type" type="radio" value="Leave a Message"<!--Leave a Message--> checked="checked" />Leave a Message&nbsp;&nbsp;
							<input name="type" type="radio" value="Complain"<!--Complain--> />Complain&nbsp;&nbsp;
							<input name="type" type="radio" value="Question"<!--Question--> />Question&nbsp;&nbsp;
							<input name="type" type="radio" value="After-sales service"<!--After-sales service--> />After-sales service&nbsp;&nbsp;
							<input name="type" type="radio" value="Wanted"<!--Wanted--> />Wanted &nbsp;&nbsp;
						</td>
					</tr>
					<tr>
						<td class="l">Title:</td>
						<td><input name="title" class="text" type="text" maxlength="30"/></td>
					</tr>
					<tr>
						<td class="l">Message Content:</td>
						<td><textarea name="text"></textarea></td>
					</tr>
					<tr>
						<td class="bt_row" colspan="2">
							<input class="button" type="button" onclick="submit_add_message()" value="Post" />
							<input class="button" type="reset" value="Reset"/>
						</td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
{literal}
<script language="javascript">
function del_message(id)
{
	if(confirm("Are you sure you want to delete this message completely?"))
	{
		ajax("post","index.php?/user/","cmd=del_message&id=" + id,
		function(data)
		{
			if(data == 1)
			{
				document.location.replace(document.location.href);
			}
		});
	}
}
function submit_add_message()
{
	var str = "";
	if(document.form_add_message.title.value == ""){str += "Message theme is Required\n";}
	if(document.form_add_message.text.value == ""){str += "Messageis Required\n";}
	if(str != "")
	{
		alert(str);
	}else{
		document.form_add_message.submit();
	}
}
</script>
{/literal}
<!--  -->