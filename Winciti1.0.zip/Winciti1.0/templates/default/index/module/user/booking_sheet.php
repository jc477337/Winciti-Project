{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>Out of stock record</span></div>
	<div class="main">
		<table class="table">
			<tr class="c">
				<td><b>Product</b></td>
				<td><b>Order Number</b></td>
				<td><b>Record Time</b></td>
				<td width="150"><b>Access Comment</b></td>
				<td width="80px"><b>Apply<!--操作--></b></td>
			</tr>
			{foreach from=$booking name=booking item=item}
			<tr class="c">
				<td>{$item.goo_title}</td>
				<td>{$item.boo_number}</td>
				<td>{$item.boo_add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
				<td>{$item.boo_note}</td>
				<td><a class="booking" href="{url entrance=$global.entrance channel='user' mod='booking_info' id=$item.boo_id}">[Check Details]</a>&nbsp;</td>
			</tr>
			{/foreach}
		</table>
		{$prefix = 'user/mod-booking_sheet'}
		{include file="module/page_link.php" page=$global.page}		
	</div>
</div>
<!--  -->