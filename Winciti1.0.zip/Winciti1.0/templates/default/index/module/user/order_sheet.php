{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>My Order</span></div>
	<div class="main">
		<table class="table">
			<tr class="c">
				<td><b>Order Number</b></td>
				<td><b>Order Time</b></td>
				<td><b>Order Total</b></td>
				<td><b>Order State</b></td>
				<td width="110px"><b>Apply<!--操作--></b></td>
			</tr>
			{foreach from=$orders name=orders item=item}
			<tr class="c">
				<td>{$item.ord_sn}</td>
				<td>{$item.ord_add_time|date_format:"%Y-%m-%d %H:%M:%S"}</td>
				<td>{$item.ord_price_total}</td>
				<td>{$item.status_name}</td>
				<td>
					<a href="{url channel='user' mod='order_info' id=$item.ord_id}">[Check]<!--查看--></a>&nbsp;&nbsp;
					<a href="{$item.ord_id}">[Cancel]</a>
				</td>
			</tr>
			{/foreach}
		</table>
		{$prefix = 'user/mod-order_sheet'}
		{include file="module/page_link.php" page=$global.page}		
	</div>
</div>
<!--  -->