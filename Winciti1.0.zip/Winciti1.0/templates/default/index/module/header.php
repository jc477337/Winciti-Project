{*<?php exit();?>*}
<div id="header">
	<div class="logo"><a href="./"><img src="{$S_ROOT}images/logo.png" /></a></div>
	<div class="cart">
		<a href="">There are {$cart_number} products in your shopping cart, total ${$cart_price} Aud</a>
		<input class="button" type="button" onclick="document.location.href = '?/flow/'" value="settle"/>
	</div>
	<div id="nav">
		<ul>
			{foreach from=$nav name=nav item=item}
			<li><a href="{$item.men_url}" {if $item.target == 1}target="_blank"{/if}>{$item.men_name}</a></li>
			{/foreach}
		</ul>
		<div class="clear"></div>
	</div>
</div>
<!--  -->
