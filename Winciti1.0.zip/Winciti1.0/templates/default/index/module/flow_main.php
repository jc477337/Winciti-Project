{*<?php exit();?>*}
<div class="block" id="cart">
	<div class="head"><span>The product you chose</span></div>
	<div class="main">
		<form name="form_cart" method="post" action="{url channel='info'}">
			<input name="cmd" type="hidden" value="cart_update"/>
			<table class="table">
				<tr class="head">
					<td width="180px"><b>Product Name</b></td>
					<td><b>RRP</b></td>
					<td><b>Our Price</b></td>
					<td width="80px"><b>Purchase quantity</b></td>
					<td><b>Subtotal</b></td>
					<td><b>Apply<!--caozuo--></b></td>
				</tr>
				{foreach from=$cart name=cart item=item}
				<tr>
					<td>
						<div class="img"><a href="{url channel='goods' id=$item.goo_id}" target="_blank"><img src="{$S_ROOT}{$item.goo_x_img}" onload="picresize(this,130,130)"/></a></div>
						<div class="title"><a href="{url channel='goods' id=$item.goo_id}" target="_blank">{$item.goo_title}</a></div>
					</td>
					<td>${$item.goo_market_price}Aud</td>
					<td>${$item.goo_shop_price}Aud</td>
					<td><input name="num[{$item.goo_id}]" class="num" type="text" value="{$item.number}" /></td>
					<td>${$item.subtotal}Aud</td>
					<td><a onclick="cart_del_goods({$item.goo_id})">[Delete]</a></td>
				</tr>
				{/foreach}
			</table>
		</form>
		<table class="count_bt">
			<tr>
				<td>Subtotal shopping amount is ${$shop_total}Aud，Comparing with RRP ${$market_total}Aud You saved ${$cut_down}Aud ({$discount}%)</td>
				<td class="bt_row"><a onclick="cart_clear()">Empty the shopping cart</a></td>
				<td class="bt_row"><a onclick="cart_update()">Refresh</a></td>
			</tr>
		</table>
		<table class="big_bt">
			<tr>
				<td><a href="./">Continue Shopping</a></td>
				<td class="c"></td>
				<td><a href="{url channel='flow' step='consignee'}">User Center</a></td>
			</tr>
		</table>
	</div>
</div>
{literal}
<script language="javascript">
function cart_del_goods(id)
{
	if(confirm("Are you sure you want to remove the item from the shopping cart?？"))
	{
		ajax("post","?/deal/","cmd=cart_del_goods&id=" + id,
		function(data)
		{
			if(data == 1)
			{
				document.location.href = "?/flow/";
			}
		});
	}
}
function cart_clear()
{
	ajax("post","?/deal/","cmd=cart_clear",
	function(data)
	{
		if(data == 1)
		{
			document.location.href = "?/flow/";
		}
	});
}
function cart_update()
{
	document.form_cart.submit();
}
</script>
{/literal}
<!--  -->