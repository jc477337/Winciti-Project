{*<?php exit();?>*}
<div id="flow">
	<form name="form_order" method="post" action="{url channel='flow' step='done'}">
		<input name="sn" type="hidden" value="{$ord_sn}"/>
		<input name="region" type="hidden" value="{$ord_region}"/>
		<input name="consignee" type="hidden" value="{$ord_consignee}"/>
		<input name="email" type="hidden" value="{$ord_email}"/>
		<input name="address" type="hidden" value="{$ord_address}"/>
		<input name="zipcode" type="hidden" value="{$ord_zipcode}"/>
		<input name="tel" type="hidden" value="{$ord_tel}"/>
		<input name="mobile" type="hidden" value="{$ord_mobile}"/>
		<input name="building" type="hidden" value="{$ord_building}"/>
		<input name="best_time" type="hidden" value="{$ord_best_time}"/>
		<div class="block">
			<div class="head"><span>Product List</span><a href="{url channel='flow'}">Change&gt;&gt;</a></div>
			<div class="main checkout">
				<table class="table">
					<tr class="head">
						<td width="180px"><b>Product Name</b></td>
						<td><b>RRP</b></td>
						<td><b>Our Price</b></td>
						<td width="80px"><b>Purchase quantity</b></td>
						<td><b>Subtotal</b></td>
					</tr>
					{foreach from=$cart name=cart item=item}
					<tr class="row">
						<td><a href="{url channel='goods' id=$item.goo_id}" target="_blank">{$item.goo_title}</a></td>
						<td>${$item.goo_market_price}Aud</td>
						<td>${$item.goo_shop_price}Aud</td>
						<td>{$item.number}</td>
						<td>${$item.subtotal}Aud</td>
					</tr>
					{/foreach}
					<tr class="row">
						<td colspan="5">Subtotal shopping amount ${$shop_total}Aud, Comparing with ${$market_total}Aud You saved ${$cut_down}Aud ({$discount}%)</td>
					</tr>
				</table>
			</div>
		</div>
		<div class="block">
			<div class="head"><span>Collector Detail</span><a href="{url channel='flow' step='consignee'}">Change&gt;&gt;</a></div>
			<div class="main checkout">
				<table class="table">
					<tr class="row">
						<td width="120px">Collector Name:</td>
						<td>{$ord_consignee}</td>
						<td width="120px">E-mail:</td>
						<td>{$ord_email}</td>
					</tr>
					<tr class="row">
						<td>Address:</td>
						<td>{$ord_address}</td>
						<td>Postcode:</td>
						<td>{$ord_zipcode}</td>
					</tr>
					<tr class="row">
						<td>Phone:</td>
						<td>{$ord_tel}</td>
						<td>Mobile:</td>
						<td>{$ord_mobile}</td>
					</tr>
					<tr class="row">
						<td>Land Mark Building:</td>
						<td>{$ord_building}</td>
						<td>Best Delivery Time:</td>
						<td>{$ord_best_time}</td>
					</tr>
				</table>
			</div>
		</div>
		<div class="block">
			<div class="head"><span>Delivery Method</span></div>
			<div class="main checkout">
				<table class="table">
					<tr class="head">
						<td width="50px"><b>Please Select</b></td>
						<td width="200px"><b>Name</b></td>
						<td><b>Delivery method description</b></td>
						<td width="150px"><b>Fee</b></td>
					</tr>
					{foreach from=$shipping name=shipping item=item}
					<tr class="row">
						<td style="text-align:center"><input name="shipping" type="radio" value="{$item.shi_id}" onclick="reset_price('shipping','{$item.shi_price}')" /></td>
						<td><b>{$item.shi_name}</b></td>
						<td>{$item.shi_text}</td>
						<td>${$item.shi_price}Aud</td>
					</tr>
					{/foreach}
				</table>
			</div>
		</div>
		<div class="block">
			<div class="head"><span>Payment Method</span></div>
			<div class="main checkout">
				<table class="table">
					<tr class="head">
						<td width="50px"><b>Please Select</b></td>
						<td width="200px"><b>Name</b></td>
						<td><b>Payment Method</b></td>
						<td width="150px"><b>Procedure fee</b></td>
					</tr>
					{foreach from=$payment name=payment item=item}
					<tr class="row">
						<td style="text-align:center"><input name="payment" type="radio" value="{$item.pay_id}" onclick="reset_price('payment','{$item.pay_price}')" /></td>
						<td><b>{$item.pay_name}</b></td>
						<td>{$item.pay_text}</td>
						<td>${$item.pay_price}Aud</td>
					</tr>
					{/foreach}
				</table>
			</div>
		</div>
		<div class="block">
			<div class="head"><span>Other Info</span></div>
			<div class="main checkout">
				<table class="table">
					<tr class="row">
						<td width="120px"><b>Order postscript:</b></td>
						<td><textarea name="message"></textarea></td>
					</tr>
				</table>
			</div>
		</div>
		<div class="block">
			<div class="head"><span>Total</span></div>
			<div class="main checkout">
				<table class="table">
					<tr>
						<td style="text-align:right">
							Product Price Total:$<span id="shop_total_1">{$shop_total}</span>Aud
							<span id="add_shipping_price"></span>
							<span id="add_payment_price"></span>
						</td>
					</tr>
					<tr>
						<td style="text-align:right">Amount due:$<span id="shop_total_2">{$shop_total}</span>Aud</td>
					</tr>
				</table>
				<div class="bt_row"><input class="button" name="message" type="button" value="Post订单" onclick="submit_order()" /></div>
			</div>
		</div>
	</form>
</div>
{literal}
<script language="javascript">
	var shipping_price = 0;
	var payment_price = 0;
	var choose_shipping = false;
	var choose_payment = false;
	function reset_price(type,price)
	{
		price = parseFloat(price);
		if(price != 0)
		{
			if(type == "shipping")
			{
				shipping_price = price;
				document.getElementById("add_shipping_price").innerHTML = "&nbsp;+&nbsp;Shipping fees:$" + price.toFixed(2) + "Aud";
			}else if(type == "payment"){
				payment_price = price;
				document.getElementById("add_payment_price").innerHTML = "&nbsp;+&nbsp;Payment Procedure fees:$" + price.toFixed(2) + "Aud";
			}
			var shop_total_1 = parseFloat(document.getElementById("shop_total_1").innerHTML);
			var shop_total_2 = shop_total_1 + shipping_price + payment_price;
			document.getElementById("shop_total_2").innerHTML = shop_total_2.toFixed(2);
		}
		if(type == "shipping"){choose_shipping = true;}
		else if(type == "payment"){choose_payment = true;}
	}
	function submit_order()
	{
		var str ="";
		if(document.form_order.region.value == ""){str += "Delivery Area is Required\n";}
		if(document.form_order.consignee.value == ""){str += "Collector Name is Required\n";}
		if(document.form_order.email.value == ""){str += "E-mail is Required\n";}
		if(document.form_order.address.value == ""){str += "Address is Required\n";}
		if(document.form_order.tel.value == ""){str += "Phone is Required\n";}
		if(!choose_shipping){str += "Please select a Delivery Method\n";}
		if(!choose_payment){str += "Please select a Payment Method\n";}
		if(str != "")
		{
			alert(str);
		}else{
			document.form_order.submit();
		}
	}
</script>
{/literal}
<!--  -->