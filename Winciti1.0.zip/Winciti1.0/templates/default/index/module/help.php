{*<?php exit();?>*}
<div class="block" id="help">
	<div class="head"><span>Help Center</span><a href="{url channel='help'}">More&gt;&gt;</a></div>
	<div class="main">
		{foreach from=$help_cat name=help_cat item=cat}
		<div class="unit">
			<div><a href="{url channel='help' cat=$cat.id}">{$cat.name}</a></div>
			<ul>
				{foreach from=$art_list[$cat.id] name=art_list item=item}
				<li><a href="{url channel='help' id=$item.art_id}" title="{$item.art_title}" target="_blank">{$item.art_title}</a></li>
				{/foreach}
			</ul>
		</div>
		{/foreach}
		<div class="clear"></div>
	</div>
</div>