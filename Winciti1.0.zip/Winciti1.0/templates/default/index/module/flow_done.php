{*<?php exit();?>*}
{if $flow_done == 1}
	<div id="flow_done">
		<div class="head">Thank you for shopping in this shop! Your order has been posted successfully, remember your order number:<span>{$ord_sn}</span></div>
		<div class="main">
			<div>
				The delivery method you selected is:<span>{$ord_shipping_name}</span>，The payment method you selected is:<span>{$ord_payment_name}</span>. Your amount due is:<span>${$ord_price_total}Aud</span><br />
				{$pay_text}<br />
				{if $pay_code == 'chinabank'}
				<form id="form_pay" method="post" action="{url channel='pay' dir='chinabank' file='send'}">
					<input type="hidden" name="v_oid" value="{$ord_sn}" />
					<input type="hidden" name="v_amount" value="{$ord_price_total}" />
					<input class="button" type="submit" value="Enter to complete the payment" />
				</form>
				{/if}
				You can &nbsp;<a href="./">Return Home</a>&nbsp;Or go to&nbsp;<a href="{url channel='user'}">User Center</a>
			</div>
		</div>
	</div>
{else}
	<div class="block" id="info">
		<div class="head"><span>System Info</span></div>
		<div class="main">
			<div>{$info_text}</div>
			<a href="{$link_href}">{$link_text}</a>
		</div>
	</div>
	<script language="javascript">
		interval = setInterval("document.location.href = '{$link_href}'",3000);
	</script>
{/if}