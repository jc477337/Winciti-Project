{*<?php exit();?>*}
{if $show_sheet == 1}
	<div class="block img_list">
		{include file="module/here.php"}
		<div class="main">
			{foreach from=$goods name=goods item=item}
			<div class="unit">
				<div class="img">
					<table>
						<tr>
							<td>
								<a href="{url channel='goods' id=$item.goo_id}" target="_blank"><img src="{$S_ROOT}{$item.goo_x_img}" onload="picresize(this,300,300)"/></a>
							</td>
						</tr>
					</table>
				</div>
				<div class="word">
					<div class="title"><a href="{url channel='goods' id=$item.goo_id}" target="_blank">{$item.goo_title}</a></div>
					<div class="market_price">RRP:<span>${$item.goo_market_price}Aud</span></div>
					<div class="shop_price">Our Price:${$item.goo_shop_price}Aud</div>
				</div>
			</div>
			{/foreach}
			<div class="clear"></div>
			{if !$goods}<div class="not_found">NO Content</div>{/if}
			{include file="module/page_link.php" page=$global.page}
		</div>
	</div>
{else}
	<div id="goods">
		<div class="info">
			<div class="l">
				<div class="img">
					<table>
						<tr>
							<td>
								<a href="{$goods.goo_img}" target="_blank"><img src="{$S_ROOT}{$goods.goo_img}" onload="picresize(this,300,300)"/></a>
							</td>
						</tr>
					</table>
				</div>
				<!--
				商品副图，二次开发中根据需要调用
				{foreach from=$goods.more_img name=more_img item=item}<img src="{$S_ROOT}{$item}" alt="{$goods.goo_title}" />{/foreach}
				-->
			</div>
			<div class="r">
				<div class="title">{$goods.goo_title}</div>
				<div class="sn">Product Bar code:{$goods.goo_sn}</div>
				<div class="brand">Product Brand:No function here!</div>
				<div class="market_price">RRP:<span>${$goods.goo_market_price}Aud</span></div>
				<div class="shop_price">Our Price:<span>${$goods.goo_shop_price}Aud</span></div>
				<div class="hits">Views:{$goods.goo_hits}</div>
				<div class="number">Stock:{$goods.goo_number}</div>
				<div class="buy_num">Purchase quantity:<input id="buy_num" type="text" value="1" /></div>
				<table>
					<tr>
						<td class="bt_row"><a onclick="add_to_cart({$goods.goo_id})">Add to Cart</a></td>
						<td class="bt_row"><a onclick="add_to_collection({$goods.goo_id})">Add to My Collect</a></td>
						<td class="bt_row"><a onclick="show_box('share',300,100);">Recommend to friends</a></td>
					</tr>
				</table>
			</div>
			<div class="clear"></div>
		</div>
		<div class="block">
			<div class="head"><span>Product attributes</span></div>
			<div class="main">
				{if $goods.goo_attribute}
				<table class="goods_att">
					<tr>
						{foreach from=$goods.att name=att item=item}
						<td width="15%">{$item.name}:</td>
						<td width="35%">{$item.value}</td>
						{if $smarty.foreach.att.index mod 2 == 1 && !$smarty.foreach.att.last}</tr><tr>{/if}
						{if $smarty.foreach.att.index mod 2 == 0 && $smarty.foreach.att.last}
						<td width="15%">&nbsp;</td>
						<td width="35%">&nbsp;</td>
						{/if}
						{/foreach}
					</tr>
				</table>
				{else}This product has not added Description yet{/if}
			</div>
		</div>
		<div class="block">
			<div class="head"><span>Product Description</span></div>
			<div class="main goods_text">
				{$goods.goo_text}
			</div>
		</div>
		{include file="module/comment.php"}
	</div>
	<!-------------------------- BOX -------------------------->
	<div class="alert" id="share">
		<div class="head">
			<div class="title">Recommend to friends</div>
			<div class="close" onclick="hide_box('share')">Close</div>
		</div>
		<div class="share_main">
			{$share_code}
		</div>
	</div>
	<!-------------------------- BOX -------------------------->
	{literal}
	<script language="javascript">
	function add_to_cart(id)
	{
		var buy_num = document.getElementById("buy_num").value;
		ajax("post","?/deal/","cmd=add_to_cart&id=" + id + "&buy_num=" + buy_num,
		function(data)
		{
			if(data == 1)
			{
				document.location.href = "?/flow/";
			}else if(data == 2){
				alert("Sorry，the product is out of stock.\n Would you want to order some？");
				document.location.href = "?/user/mod-booking_add/goods_id-" + id + "/";
			}
		});
	}
	function add_to_collection(id)
	{
		ajax("post","?/deal/","cmd=add_to_collection&id=" + id,
		function(data)
		{
			if(data == 0)
			{
				alert("You can not do that without login");
			}else if(data == 1)
			{
				alert("This item has been successfully added to your collect");
			}else if(data == 2){
				alert("This item already exists in your collect");
			}
		});
	}
	</script>
	{/literal}
{/if}
<!--  -->
