{*<?php exit();?>*}
<div class="block goods_tree">
	<div class="head"><span>Categories</span></div>
	<div class="main">
		{foreach from=$goods_tree name=goods_tree item=item}
		{if $item.grade == 1 && !$smarty.foreach.goods_tree.first}</ul><div class="clear"></div>{/if}
		{if $item.grade == 1}<div class="cat1"><a href="{url channel='goods' cat=$item.id}">{$item.name}</a></div>{/if}
		{if $item.grade == 1 && !$smarty.foreach.goods_tree.last}<ul>{/if}
		{if $item.grade == 2}<li><a href="{url channel='goods' cat=$item.id}">{$item.name}</a></li>{/if}
		{/foreach}
		</ul><div class="clear"></div>
	</div>
</div>
<!--  -->
