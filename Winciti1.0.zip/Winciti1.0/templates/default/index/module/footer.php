{*<?php exit();?>*}
<div id="footer">
	<div class="nav">
		{foreach from=$footer_nav name=footer_nav item=item}
		<a href="{$item.men_url}">{$item.men_name}</a>
		{if !$smarty.foreach.footer_nav.last}|{/if}
		{/foreach}
	</div>
</div>
<!--  -->
