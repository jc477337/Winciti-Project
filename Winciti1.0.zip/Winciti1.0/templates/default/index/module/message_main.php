{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>Message</span></div>
	<div class="main">
		<div class="mes_sheet">
			<ul>
				{foreach from=$message name=message item=item}
				<li>
					<table>
						<tr>
							<td><b>{if $item.user_name}{$item.user_name}{else}Anonymous User{/if}:</b><span>{$item.mes_title}</span>&nbsp;&nbsp;（{$item.mes_add_time|date_format:"%Y-%m-%d %H:%M:%S"}）</td>
						</tr>
						<tr>
							<td>{$item.mes_text}</td>
						</tr>						
					</table>
				</li>
				{/foreach}
			</ul>
			{if !$message}<div class="not_found">NO Content</div>{/if}
		</div>
		{$prefix = 'message'}
		{include file="module/page_link.php" page=$global.page}
		<div id="leave_word">
			<form name="form_add_message" method="post" action="{url channel='info'}">
				<input name="cmd" type="hidden" value="add_message"/>
				<table>
					<tr>
						<td class="l">User:</td>
						<td>
							{if $user_name}{$user_name}{else}Anonymous User{/if}&nbsp;&nbsp;
							<input name="show" type="checkbox" value="2"/>Whisper
						</td>
					</tr>
					<tr>
						<td class="l">E-mail:</td>
						<td><input name="email" class="text" type="text" value="{$user_email}" /></td>
					</tr>
					<tr>
						<td class="l">Message Type:</td>
						<td>
							<input name="type" type="radio" value="Feedback" checked="checked" />Feedback&nbsp;&nbsp;
							<input name="type" type="radio" value="Subscribtion" />Subscribtion&nbsp;&nbsp;
						</td>
					</tr>
					<tr>
						<td class="l">Title:</td>
						<td><input name="title" class="text" type="text" maxlength="30"/></td>
					</tr>
					<tr>
						<td class="l">Content:</td>
						<td><textarea name="text"></textarea></td>
					</tr>
					<tr>
						<td class="bt_row" colspan="2">
							<input class="button" type="button" onclick="submit_add_message()" value="Post" />
							<input class="button" type="reset" value="Reset"/>
						</td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
{literal}
<script language="javascript">
function submit_add_message()
{
	var str = "";
	if(document.form_add_message.email.value == ""){str += "E-mail is Required\n";}
	if(document.form_add_message.title.value == ""){str += "Message Theme is Required\n";}
	if(document.form_add_message.text.value == ""){str += "Message is Required\n";}
	if(str != "")
	{
		alert(str);
	}else{
		document.form_add_message.submit();
	}
}
</script>
{/literal}
<!--  -->