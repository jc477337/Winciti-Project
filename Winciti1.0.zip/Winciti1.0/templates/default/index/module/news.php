{*<?php exit();?>*}
<div class="block" id="news">
	<div class="head"><span>News</span></div>
	<div class="main">
		<ul>
			{foreach from=$news name=news item=item}
			<li>
				<a href="{url channel='article' id=$item.art_id}" title="{$item.art_title}" target="_blank">{$item.short_title}</a>
				<span>{$item.art_add_time|date_format:"%Y-%m-%d"}</span>
				<div class="clear"></div>
			</li>
			{/foreach}
		</ul>
	</div>
</div>
<!--  -->
