<?php
function module_search_main()
{
	global $global,$smarty;
	$global['key'] = rawurldecode($global['key']);
	$obj = new goods();
	$obj->set_field('goo_id,goo_title,goo_x_img,goo_market_price,goo_shop_price');
	$obj->set_where("goo_title like '%" . $global['key'] . "%'");
	$len = get_varia('img_list_len');
	$obj->set_page_size($len ? $len : 12);
	$obj->set_page_num($global['page']);
	$sheet = $obj->get_sheet();
	for($i = 0; $i < count($sheet); $i ++)
	{
		$sheet[$i]['short_title'] = cut_str($sheet[$i]['goo_title'],11);
	}
	set_link($obj->get_page_sum());
	$smarty->assign('search',$sheet);
}
//
?>