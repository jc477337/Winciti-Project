<?php
function module_help_tree()
{
	global $smarty;
	$family = implode(',',get_cat_family('cat_art',1));
	$obj = new cat_art();
	$obj->set_where("cat_id in ($family)");
	$smarty->assign('help_tree',$obj->get_tree());
}
//
?>