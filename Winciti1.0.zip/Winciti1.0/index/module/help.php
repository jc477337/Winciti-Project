<?php
function module_help()
{
	global $smarty;
	$family = implode(',',get_cat_family('cat_art',1));
	$tree_obj = new cat_art();
	$tree_obj->set_where("cat_id in ($family)");
	$tree_obj->set_page_size(7);
	$help_cat = $tree_obj->get_tree();
	$art_list = array();
	$list_len = get_varia('index_help_list_len');
	if(count($help_cat) > 1)
	{
		$help_cat = array_slice($help_cat,1);
		for($i = 0; $i < count($help_cat); $i ++)
		{
			$cat = $help_cat[$i]['id'];
			$family = implode(',',get_cat_family('cat_art',$cat));
			$obj = new article();
			$obj->set_field('art_id,art_title,art_add_time');
			$obj->set_where("art_cat_id in ($family)");
			$obj->set_page_size($list_len ? $list_len : 5);
			$list = $obj->get_list();
			for($j = 0; $j < count($list); $j ++)
			{
				$list[$j]['art_title'] = cut_str($list[$j]['art_title'],10);
			}
			$art_list[$cat] = $list;
		}
	}
	$smarty->assign('help_cat',$help_cat);
	$smarty->assign('art_list',$art_list);
}
//
?>