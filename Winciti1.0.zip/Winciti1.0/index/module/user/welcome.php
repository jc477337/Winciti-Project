<?php
function module_welcome()
{
	global $global,$smarty;
	$cut_time = time() - 30 * 24 * 60 * 60;
	$obj = new orders();
	$obj->set_where('ord_user_id = '.$global['user_id']);
	$obj->set_where("ord_add_time > $cut_time");
	$smarty->assign('order_count',$obj->get_count());
	$smarty->assign('user_name',get_data('users',$global['user_id'],'use_username'));
	$smarty->assign('prev_login',date('Y-m-d H:i:s',get_data('users',$global['user_id'],'use_prev_login')));
	$smarty->assign('user_money',sprintf('%.2f',get_data('users',$global['user_id'],'use_money')));
}
//
?>