<?php
function module_profile()
{
	global $global,$smarty;
	$obj = new users();
	$obj->set_where('use_id = '.$global['user_id']);
	$one = $obj->get_one();
	if(count($one) > 0)
	{
		$birthday = $one['use_birthday'];
		$smarty->assign('use_birthday_year',date('Y',$birthday));
		$smarty->assign('use_birthday_month',date('m',$birthday));
		$smarty->assign('use_birthday_day',date('d',$birthday));
		$smarty->assign('use_sex',$one['use_sex']);
		$smarty->assign('use_real_name',$one['use_real_name']);
		$smarty->assign('use_email',$one['use_email']);
		$smarty->assign('use_tel',$one['use_tel']);
		$smarty->assign('use_phone',$one['use_phone']);
		$smarty->assign('use_address',$one['use_address']);
		$smarty->assign('use_question',$one['use_question']);
		$smarty->assign('use_answer',$one['use_answer']);
	}else{
		rhs_error();
	}
}
//
?>