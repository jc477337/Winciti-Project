<?php
if(check_user_login() !== 0)
{
	$cmd = post('cmd');
	$cmd();
}else{
	exit();
}
function edit_profile()
{
	global $global,$smarty;
	$use_birthday = mktime(8,0,0,post('birthday_month'),post('birthday_day'),post('birthday_year'));
	$use_sex = post('sex');
	$use_real_name = post('real_name');
	$use_email = post('email');
	$use_tel = post('tel');
	$use_phone = post('phone');
	$use_address = post('address');
	$use_question = post('question');
	$use_answer = post('answer');
	
	if($use_real_name == ''){
		$info_text = '对不起，真实姓名不能为空';
	}elseif($use_email == ''){
		$info_text = '对不起，Email不能为空';
	}elseif($use_tel == ''){
		$info_text = '对不起，电话不能为空';
	}elseif($use_address == ''){
		$info_text = '对不起，地址不能为空';
	}else{
		$obj = new users();
		$obj->set_value('use_birthday',$use_birthday);
		$obj->set_value('use_sex',$use_sex);
		$obj->set_value('use_real_name',$use_real_name);
		$obj->set_value('use_email',$use_email);
		$obj->set_value('use_tel',$use_tel);
		$obj->set_value('use_phone',$use_phone);
		$obj->set_value('use_address',$use_address);
		$obj->set_value('use_question',$use_question);
		$obj->set_value('use_answer',$use_answer);
		$obj->set_where('use_id = '.$global['user_id']);
		$obj->edit();
		$info_text = '执行完毕';
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text','返回');
	$smarty->assign('link_href',url(array('channel'=>'user','mod'=>'profile')));
}
function edit_pwd()
{
	global $global,$smarty;
	$old_pwd = post('old_pwd');
	$new_pwd = post('new_pwd');
	$re_pwd = post('re_pwd');
	if(strlen($old_pwd) < 6){
		$info_text = '对不起，旧密码长度不能小于6个字符';
	}elseif(strlen($old_pwd) > 15){
		$info_text = '对不起，旧密码长度不能大于15个字符';
	}elseif(strlen($new_pwd) < 6){
		$info_text = '对不起，新密码长度不能小于6个字符';
	}elseif(strlen($new_pwd) > 15){
		$info_text = '对不起，新密码长度不能大于15个字符';
	}elseif($new_pwd != $re_pwd){
		$info_text = '对不起，两次输入密码不一致';
	}else{
		$use_password = md5($old_pwd);
		$obj = new users();
		$obj->set_where('use_id = '.$global['user_id']);
		$obj->set_where("use_password = '$use_password'");
		if($obj->get_count() > 0)
		{
			$use_password = md5($new_pwd);
			$obj->set_value('use_password',$use_password);
			$obj->set_where('');
			$obj->set_where('use_id = '.$global['user_id']);
			$obj->edit();
			$info_text = '执行完毕';
		}else{
			$info_text = '对不起，旧密码不正确';
		}
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text','返回');
	$smarty->assign('link_href',url(array('channel'=>'user','mod'=>'profile')));
}
function edit_consignee()
{
	global $global,$smarty;
	$con_id = post('id');
	$con_region = post('region_1').'|'.post('region_2').'|'.post('region_3');
	$con_consignee = post('consignee');
	$con_email = post('email');
	$con_address = post('address');
	$con_zipcode = post('zipcode');
	$con_tel = post('tel');
	$con_mobile = post('mobile');
	$con_building = post('building');
	$con_best_time = post('best_time');
	if($con_region == '')
	{
		$info_text = '配送区域不能为空';
	}elseif($con_consignee == ''){
		$info_text = '收货人姓名不能为空';
	}elseif($con_email == ''){
		$info_text = '电子邮件地址不能为空';
	}elseif($con_address == ''){
		$info_text = '详细地址不能为空';
	}elseif($con_tel == ''){
		$info_text = '电话不能为空';
	}else{
		$obj = new consignee();
		$obj->set_value('con_region',$con_region);
		$obj->set_value('con_consignee',$con_consignee);
		$obj->set_value('con_email',$con_email);
		$obj->set_value('con_address',$con_address);
		$obj->set_value('con_zipcode',$con_zipcode);
		$obj->set_value('con_tel',$con_tel);
		$obj->set_value('con_mobile',$con_mobile);
		$obj->set_value('con_building',$con_building);
		$obj->set_value('con_best_time',$con_best_time);
		$obj->set_where("con_id = $con_id");
		$obj->set_where('con_user_id = '.$global['user_id']);
		$obj->edit();
		$info_text = '您的收货地址信息已成功更新';
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text','返回');
	$smarty->assign('link_href',url(array('channel'=>'user','mod'=>'address_list')));	
}
function add_consignee()
{
	global $global,$smarty;
	$con_region = post('region_1').'|'.post('region_2').'|'.post('region_3');
	$con_consignee = post('consignee');
	$con_email = post('email');
	$con_address = post('address');
	$con_zipcode = post('zipcode');
	$con_tel = post('tel');
	$con_mobile = post('mobile');
	$con_building = post('building');
	$con_best_time = post('best_time');
	
	if($con_region == '')
	{
		$info_text = '配送区域不能为空';
	}elseif($con_consignee == ''){
		$info_text = '收货人姓名不能为空';
	}elseif($con_email == ''){
		$info_text = '电子邮件地址不能为空';
	}elseif($con_address == ''){
		$info_text = '详细地址不能为空';
	}elseif($con_tel == ''){
		$info_text = '电话不能为空';
	}else{
		$obj = new consignee();
		$obj->set_value('con_user_id',$global['user_id']);
		$obj->set_value('con_region',$con_region);
		$obj->set_value('con_consignee',$con_consignee);
		$obj->set_value('con_email',$con_email);
		$obj->set_value('con_address',$con_address);
		$obj->set_value('con_zipcode',$con_zipcode);
		$obj->set_value('con_tel',$con_tel);
		$obj->set_value('con_mobile',$con_mobile);
		$obj->set_value('con_building',$con_building);
		$obj->set_value('con_best_time',$con_best_time);
		$obj->set_value('con_lang',S_LANG);
		$obj->add();
		$info_text = '您的收货地址信息已成功更新';
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text','返回');
	$smarty->assign('link_href',url(array('channel'=>'user','mod'=>'address_list')));	
}
function del_consignee()
{
	global $global;
	$con_id = post('id');
	$obj = new consignee();
	$obj->set_where("con_id = $con_id");
	$obj->set_where('con_user_id = '.$global['user_id']);
	$obj->del();
	echo 1;
	exit();
}
function del_collection()
{
	global $global;
	$col_id = post('id');
	$obj = new collection();
	$obj->set_where("col_id = $col_id");
	$obj->set_where('col_user_id = '.$global['user_id']);
	$obj->del();
	echo 1;
	exit();
}
function add_message()
{
	global $global,$smarty;
	$mes_type = post('type');
	$mes_title = post('title');
	$mes_text = post('text');
	if($mes_type == '')
	{
		$info_text = '对不起，您提交的信息不充足';
	}elseif($mes_title == ''){
		$info_text = '留言标题为空';
	}elseif($mes_text == ''){
		$info_text = '留言内容为空';
	}else{
		$obj = new message();
		$obj->set_value('mes_user_id',$global['user_id']);
		$obj->set_value('mes_type',$mes_type);
		$obj->set_value('mes_title',$mes_title);
		$obj->set_value('mes_text',$mes_text);
		$obj->set_value('mes_add_time',time());
		$obj->set_value('mes_show',0);
		$obj->set_value('mes_lang',S_LANG);
		$obj->add();
		$info_text = '提交留言成功';
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text','返回');
	$smarty->assign('link_href',url(array('channel'=>'user','mod'=>'message_list')));	
}
function del_message()
{
	global $global;
	$mes_id = post('id');
	$obj = new message();
	$obj->set_where("mes_id = $mes_id");
	$obj->set_where('mes_user_id = '.$global['user_id']);
	$obj->del();
	echo 1;
	exit();
}
function add_booking()
{
	global $global,$smarty;
	$boo_goods_id = post('goods_id');
	$boo_number = post('number');
	$boo_text = post('text');
	$boo_consignee = post('consignee');
	$boo_email = post('email');
	$boo_tel = post('tel');
	$link_text = '返回';
	$link_href = url(array('entrance'=>$global['entrance'],'channel'=>'user','mod'=>'booking_add','goods_id'=>$boo_goods_id));
	if($boo_goods_id == '' || $boo_number == '' || $boo_text == '' || $boo_consignee == '' || $boo_email == '' || $boo_tel == '')
	{
		$info_text = '对不起，您所提交的信息有误';
	}else{
		$obj = new booking();
		$obj->set_value('boo_user_id',$global['user_id']);
		$obj->set_value('boo_goods_id',$boo_goods_id);
		$obj->set_value('boo_number',$boo_number);
		$obj->set_value('boo_text',$boo_text);
		$obj->set_value('boo_consignee',$boo_consignee);
		$obj->set_value('boo_email',$boo_email);
		$obj->set_value('boo_tel',$boo_tel);
		$obj->set_value('boo_add_time',time());
		$obj->set_value('boo_lang',S_LANG);
		$obj->add();
		if(intval(get_varia('sentmail')))
		{
			$email_title = '您的网站有了新的商品订购信息';
			$email_text = '商品名称：' . get_data('goods',$boo_goods_id,'goo_title') . '<br />';
			$email_text .= "订购数量：$boo_number <br />";
			$email_text .= "联系人：$boo_consignee <br />";
			$email_text .= "电子邮箱：$boo_email <br />";
			$email_text .= "联系电话：$boo_tel <br />";
			$email_text .= "附加说明：$boo_text <br />";
			call_send_email($email_title,$email_text,$global['user_id']);
		}
		$info_text = '添加缺货登记成功';
		$link_text = '进入用户中心';
		$link_href = url(array('entrance'=>$global['entrance'],'channel'=>'user','mod'=>'booking_sheet'));
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text',$link_text);
	$smarty->assign('link_href',$link_href);
}
function del_booking()
{
	global $global;
	$boo_id = post('id');
	$obj = new booking();
	$obj->set_where("boo_id = $boo_id");
	$obj->set_where('boo_user_id = '.$global['user_id']);
	$obj->del();
	echo 1;
}
//
?>