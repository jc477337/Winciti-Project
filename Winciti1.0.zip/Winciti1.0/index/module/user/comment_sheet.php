<?php
function module_comment_sheet()
{
	global $global,$smarty;
	$obj = new comment();
	$obj->set_where('com_user_id = '.$global['user_id']);
	$obj->set_page_size(5);
	$obj->set_page_num($global['page']);
	$sheet = $obj->get_sheet();
	for($i = 0; $i < count($sheet); $i ++)
	{
		$sheet[$i]['user_name'] = get_data('users',$sheet[$i]['com_user_id'],'use_username');
	}
	set_link($obj->get_page_sum());
	$smarty->assign('comment',$sheet);
}
//
?>