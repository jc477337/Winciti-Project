<?php
function module_article_tree()
{
	global $smarty;
	$family = implode(',',get_cat_family('cat_art',1));
	$obj = new cat_art();
	$obj->set_where("cat_id not in ($family)");
	$smarty->assign('article_tree',$obj->get_tree());
}
//
?>