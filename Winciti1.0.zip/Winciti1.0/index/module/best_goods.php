<?php
function module_best_goods()
{
	global $smarty;
	$list_len = get_varia('index_best_goods_len');
	$obj = new goods();
	$obj->set_field('goo_id,goo_title,goo_x_img,goo_market_price,goo_shop_price');
	$obj->set_where('goo_best = 1');
	$obj->set_page_size($list_len ? $list_len : 10);
	$list = $obj->get_list();
	for($i = 0; $i < count($list); $i ++)
	{
		$list[$i]['goo_title'] = cut_str($list[$i]['goo_title'],11);
	}
	$smarty->assign('best_goods',$list);
}
//
?>