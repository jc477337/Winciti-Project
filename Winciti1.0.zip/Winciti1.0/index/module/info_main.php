<?php
function module_info_main()
{
	switch(post('cmd'))
	{
		case 'cart_update': cart_update();break;
		case 'register': register();break;
		case 'user_login': user_login();break;
		case 'add_comment': add_comment();break;
		case 'add_message': add_message();break;
	}
}
function cart_update()
{
	global $smarty;
	$json = get_cart_json();
	if($json != '' && $json != 'null')
	{
		if($arr = json_decode($json,true))
		{
			for($i = 0; $i < count($_POST['num']); $i ++)
			{
				$id = key($_POST['num']);
				$buy_num = strict($_POST['num'][$id]);
				$arr[$id] = $buy_num;
				next($_POST['num']);
			}
		}
		set_cart_json(json_encode($arr));
	}else{
		set_cart_json('');
	}
	$smarty->assign('info_text','购物车更新成功!');
	$smarty->assign('link_href',url(array('channel'=>'flow')));
	$smarty->assign('link_text','返回购物车');
}
function register()
{
	global $global,$smarty;
	$use_username = post('username');
	$use_password = post('password');
	$re_password = post('re_password');
	$use_real_name = post('real_name');
	$use_email = post('email');
	$use_tel = post('tel');
	$use_address = post('address');
	$agreement = post('agreement');
	
	$flag = false;
	$obj = new users();
	$obj->set_where("use_username = '$use_username'");
	if(
	$obj->get_count() > 0 ||
	strlen($use_username) < 6 ||
	strlen($use_username) > 15 ||
	strlen($use_password) < 6 ||
	strlen($use_password) > 15 ||
	$use_password != $re_password ||
	$use_real_name == '' ||
	$use_email == '' ||
	$use_tel == '' ||
	$use_address == '' ||
	$agreement != 1
	){
		$info_text = '对不起，您所提交的信息有误';
	}else{
		$flag = true;
		$use_password = md5($use_password);
		$obj->set_value('use_username',$use_username);
		$obj->set_value('use_password',$use_password);
		$obj->set_value('use_real_name',$use_real_name);
		$obj->set_value('use_email',$use_email);
		$obj->set_value('use_tel',$use_tel);
		$obj->set_value('use_address',$use_address);
		$obj->set_value('use_reg_time',time());
		$obj->add();
		set_cookie('user_username',$use_username);
		set_cookie('user_password',$use_password);
	}
	if($flag)
	{
		$info_text = '注册新用户成功!';
		$link_href = url(array('channel'=>'user'));
		$link_text = '进入用户中心';
	}else{
		$link_href = url(array('channel'=>'user','mod'=>'register'));
		$link_text = '返回';
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_href',$link_href);
	$smarty->assign('link_text',$link_text);
}
function user_login()
{
	global $global,$smarty;
	$info_text = post('info_text');
	$link_text = post('link_text');
	$link_href = post('link_href');
	$username = post('username');
	$password = post('password');
	
	if(strlen($username) > 30){$username = substr($username,30);}
	if(strlen($password) > 30){$password = substr($password,30);}
	if($username == '' or $password == '')
	{
		unset_cookie('user_username');
		unset_cookie('user_password');
		$info_text = '对不起，用户名和密码不能为空';
		$link_text = '重新登录';
	}else{
		$password = md5($password);
		$obj = new users();
		$obj->set_field('use_id,use_last_login');
		$obj->set_where("use_username = '$username'");
		$obj->set_where("use_password = '$password'");
		$one = $obj->get_one();
		if(count($one) !== 0)
		{
			set_cookie('user_username',$username);
			set_cookie('user_password',$password);
			$use_id = $one['use_id'];
			$use_prev_login = $one['use_last_login'];
			$use_last_login = time();
			$obj->set_value('use_prev_login',$use_prev_login);
			$obj->set_value('use_last_login',$use_last_login);
			$obj->set_where('');
			$obj->set_where("use_id = $use_id");
			$obj->edit();
			$info_text = $info_text != '' ? $info_text : '登录用户中心成功';
			$link_text = $link_text != '' ? $link_text : '进入用户中心';
		}else{
			unset_cookie('user_username');
			unset_cookie('user_password');
			$info_text = '对不起，用户名不存在或密码不正确';
			$link_text = '重新登录';
		}
	}
	if($link_href != '')
	{
		$link_href = url(array('prefix'=>$link_href));
	}else{
		$link_href = url(array('channel'=>'user'));
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text',$link_text);
	$smarty->assign('link_href',$link_href);
}
function add_comment()
{
	global $global,$smarty;
	$com_type = post('type');
	$com_page_id = post('page_id');
	$com_email = post('email');
	$com_rank = post('rank');
	$com_text = post('text');
	if($com_type == '' || $com_page_id == '' || $com_rank == '')
	{
		$info_text = '对不起，您所提交的信息不完整';
	}elseif($com_email == ''){
		$info_text = '请输入您的电子邮件地址';
	}elseif($com_text == ''){
		$info_text = '您没有输入评论的内容';
	}else{
		$com_add_time = time();
		$obj = new comment();
		$obj->set_value('com_user_id',$global['user_id']);
		$obj->set_value('com_type',$com_type);
		$obj->set_value('com_page_id',$com_page_id);
		$obj->set_value('com_email',$com_email);
		$obj->set_value('com_rank',$com_rank);
		$obj->set_value('com_text',$com_text);
		$obj->set_value('com_add_time',$com_add_time);
		$obj->set_value('com_show',0);
		$obj->set_value('com_lang',S_LANG);
		$obj->add();
		$info_text = '您的评论已成功发表,请等待管理员的审核';
	}
	$link_href = url(array('channel'=>$com_type,'id'=>$com_page_id));
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text','返回');
	$smarty->assign('link_href',$link_href);
}
function add_message()
{
	global $global,$smarty;
	$mes_email = post('email');
	$mes_type = post('type');
	$mes_title = post('title');
	$mes_text = post('text');
	$mes_show = post('show');
	if($mes_type == '')
	{
		$info_text = '对不起，您提交的信息不充足';
	}elseif($mes_email == ''){
		$info_text = '请输入您的电子邮件地址';
	}elseif($mes_title == ''){
		$info_text = '留言标题为空';
	}elseif($mes_text == ''){
		$info_text = '留言内容为空';
	}else{
		$mes_add_time = time();
		if($mes_show != '2')
		{
			$mes_show = '0';
		}
		$obj = new message();
		$obj->set_value('mes_user_id',$global['user_id']);
		$obj->set_value('mes_type',$mes_type);
		$obj->set_value('mes_email',$mes_email);
		$obj->set_value('mes_title',$mes_title);
		$obj->set_value('mes_text',$mes_text);
		$obj->set_value('mes_add_time',$mes_add_time);
		$obj->set_value('mes_show',$mes_show);
		$obj->set_value('mes_lang',S_LANG);
		$obj->add();
		$info_text = '提交留言成功,请等待管理员的审核';
	}
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_text','返回');
	$smarty->assign('link_href',url(array('channel'=>'message')));
}
//
?>