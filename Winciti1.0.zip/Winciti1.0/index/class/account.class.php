<?php
class account extends table
{
	public function __construct()
	{
		parent::__construct();
		$this->set_table(S_DB_PREFIX.'account');
		$this->set_order('acc_id');
	}
	
	public function get_status_name($val)
	{
		switch($val)
		{
			case 0: return '失败';break;
			case 1: return '未完成';break;
			case 2: return '成功';break;
		}
	}	
	
	protected function deal($field,$val)
	{
		if($field == 'acc_amount'){
			$val = sprintf('%.2f',$val);
		}
		return $val;
	}
}
//
?>