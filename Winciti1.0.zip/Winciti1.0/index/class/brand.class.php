<?php
class brand extends table
{
	public function __construct()
	{
		parent::__construct();
		$this->set_table(S_DB_PREFIX.'brand');
		$this->set_where("bra_lang = '".S_LANG."'");
		$this->set_where('bra_show = 1');
		$this->set_order('bra_top');
		$this->set_order('bra_index');
		$this->set_order('bra_id');
	}
}
//
?>