<?php
class region extends category
{
	public function __construct()
	{
		parent::__construct();
		$this->set_prefix('reg_');
		$this->set_table(S_DB_PREFIX.'region');
		$this->set_where("reg_lang = '".S_LANG."'");
		$this->set_where('reg_show = 1');
		$this->set_order('reg_top');
		$this->set_order('reg_index');
		$this->set_order('reg_id','asc');
	}
	
	public function get_option($parent = 0,$id = 0)
	{
		$str = '';
		$list = $this->get_list();
		if(count($list) > 0)
		{
			for($i = 0; $i < count($list); $i++)
			{
				$reg_id = $list[$i]['reg_id'];
				$reg_name = $list[$i]['reg_name'];
				if($id == $reg_id)
				{
					$selected = 'selected="selected"';
				}else{
					$selected = '';
				}
				$str .= '<option value="'.$reg_id.'" '.$selected.'>'.$reg_name.'</option>';
			}
		}
		return $str;
	}
}
//
?>