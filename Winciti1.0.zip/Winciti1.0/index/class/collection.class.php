<?php
class collection extends table
{
	public function __construct()
	{
		parent::__construct();
		$this->set_table(S_DB_PREFIX.'collection');
		$this->set_where("col_lang = '".S_LANG."'");
		$this->set_order('col_id');
	}
}
//
?>