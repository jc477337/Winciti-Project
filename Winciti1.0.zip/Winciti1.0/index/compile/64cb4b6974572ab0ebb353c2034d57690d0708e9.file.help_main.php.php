<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 17:47:22
         compiled from "templates/default/index\module\help_main.php" */ ?>
<?php /*%%SmartyHeaderCode:153955a5d85b4938b07-17935055%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '64cb4b6974572ab0ebb353c2034d57690d0708e9' => 
    array (
      0 => 'templates/default/index\\module\\help_main.php',
      1 => 1516096031,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '153955a5d85b4938b07-17935055',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d85b4af824',
  'variables' => 
  array (
    'show_sheet' => 0,
    'article' => 0,
    'item' => 0,
    'global' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d85b4af824')) {function content_5a5d85b4af824($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'E:\wamp\www\oneb2c\smarty\plugins\modifier.date_format.php';
?>
<?php if ($_smarty_tpl->tpl_vars['show_sheet']->value==1){?>
	<div class="block">
		<?php echo $_smarty_tpl->getSubTemplate ("module/here.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

		<div class="main">
			<ul class="art_sheet">
				<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['article']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
				<li><a href="<?php echo url(array('channel'=>'help','id'=>$_smarty_tpl->tpl_vars['item']->value['art_id']),$_smarty_tpl);?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['art_title'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['item']->value['art_title'];?>
</a><span><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['item']->value['art_add_time'],"%Y-%m-%d");?>
</span><div class="clear"></div></li>
				<?php } ?>
			</ul>
			<?php if (!$_smarty_tpl->tpl_vars['article']->value){?><div class="not_found">NO Content</div><?php }?>
			<?php if ($_smarty_tpl->tpl_vars['global']->value['cat']){?><?php $_smarty_tpl->tpl_vars['prefix'] = new Smarty_variable(('help/cat-').($_smarty_tpl->tpl_vars['global']->value['cat']), null, 0);?><?php }else{ ?><?php $_smarty_tpl->tpl_vars['prefix'] = new Smarty_variable('help', null, 0);?><?php }?>
			<?php echo $_smarty_tpl->getSubTemplate ("module/page_link.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('page'=>$_smarty_tpl->tpl_vars['global']->value['page']), 0);?>

		</div>
	</div>
<?php }else{ ?>
	<div class="block">
		<?php echo $_smarty_tpl->getSubTemplate ("module/here.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

		<div class="main">
			<div id="article">
				<div class="title"><h3><?php echo $_smarty_tpl->tpl_vars['article']->value['art_title'];?>
</h3></div>
				<div class="info">
					From:<?php echo $_smarty_tpl->tpl_vars['article']->value['art_author'];?>
&nbsp;&nbsp;&nbsp;Time:<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['article']->value['art_add_time'],"%Y-%m-%d %H:%M:%S");?>

				</div>
				<div class="content"><?php echo $_smarty_tpl->tpl_vars['article']->value['art_text'];?>
</div>
				<?php $_smarty_tpl->tpl_vars['prefix'] = new Smarty_variable('help', null, 0);?>
				<?php echo $_smarty_tpl->getSubTemplate ("module/prev_next.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			</div>
		</div>
	</div>
<?php }?>
<!--  --><?php }} ?>