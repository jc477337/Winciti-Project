<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:46:18
         compiled from "templates/default/index\module\goods_tree.php" */ ?>
<?php /*%%SmartyHeaderCode:259425a5d7f196add51-53193657%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6083629d1d798101649a847ac92025a6a963bd20' => 
    array (
      0 => 'templates/default/index\\module\\goods_tree.php',
      1 => 1516092370,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '259425a5d7f196add51-53193657',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f19783f8',
  'variables' => 
  array (
    'goods_tree' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f19783f8')) {function content_5a5d7f19783f8($_smarty_tpl) {?>
<div class="block goods_tree">
	<div class="head"><span>Categories</span></div>
	<div class="main">
		<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['goods_tree']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['item']->total= $_smarty_tpl->_count($_from);
 $_smarty_tpl->tpl_vars['item']->iteration=0;
 $_smarty_tpl->tpl_vars['item']->index=-1;
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
 $_smarty_tpl->tpl_vars['item']->iteration++;
 $_smarty_tpl->tpl_vars['item']->index++;
 $_smarty_tpl->tpl_vars['item']->first = $_smarty_tpl->tpl_vars['item']->index === 0;
 $_smarty_tpl->tpl_vars['item']->last = $_smarty_tpl->tpl_vars['item']->iteration === $_smarty_tpl->tpl_vars['item']->total;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['goods_tree']['first'] = $_smarty_tpl->tpl_vars['item']->first;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['goods_tree']['last'] = $_smarty_tpl->tpl_vars['item']->last;
?>
		<?php if ($_smarty_tpl->tpl_vars['item']->value['grade']==1&&!$_smarty_tpl->getVariable('smarty')->value['foreach']['goods_tree']['first']){?></ul><div class="clear"></div><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['item']->value['grade']==1){?><div class="cat1"><a href="<?php echo url(array('channel'=>'goods','cat'=>$_smarty_tpl->tpl_vars['item']->value['id']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a></div><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['item']->value['grade']==1&&!$_smarty_tpl->getVariable('smarty')->value['foreach']['goods_tree']['last']){?><ul><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['item']->value['grade']==2){?><li><a href="<?php echo url(array('channel'=>'goods','cat'=>$_smarty_tpl->tpl_vars['item']->value['id']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
</a></li><?php }?>
		<?php } ?>
		</ul><div class="clear"></div>
	</div>
</div>
<!--  -->
<?php }} ?>