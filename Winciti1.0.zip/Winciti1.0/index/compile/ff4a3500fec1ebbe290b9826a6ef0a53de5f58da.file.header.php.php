<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:52:25
         compiled from "templates/default/index\module\header.php" */ ?>
<?php /*%%SmartyHeaderCode:54255a5a0f31819571-59480524%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ff4a3500fec1ebbe290b9826a6ef0a53de5f58da' => 
    array (
      0 => 'templates/default/index\\module\\header.php',
      1 => 1516092738,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '54255a5a0f31819571-59480524',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5a0f3189529',
  'variables' => 
  array (
    'S_ROOT' => 0,
    'cart_number' => 0,
    'cart_price' => 0,
    'nav' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5a0f3189529')) {function content_5a5a0f3189529($_smarty_tpl) {?>
<div id="header">
	<div class="logo"><a href="./"><img src="<?php echo $_smarty_tpl->tpl_vars['S_ROOT']->value;?>
images/logo.png" /></a></div>
	<div class="cart">
		<a href="">您的购物车中有 <?php echo $_smarty_tpl->tpl_vars['cart_number']->value;?>
 件商品，总计金额 ￥<?php echo $_smarty_tpl->tpl_vars['cart_price']->value;?>
 元</a>
		<input class="button" type="button" onclick="document.location.href = '?/flow/'" value="settle"/>
	</div>
	<div id="nav">
		<ul>
			<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['nav']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
			<li><a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['men_url'];?>
" <?php if ($_smarty_tpl->tpl_vars['item']->value['target']==1){?>target="_blank"<?php }?>><?php echo $_smarty_tpl->tpl_vars['item']->value['men_name'];?>
</a></li>
			<?php } ?>
		</ul>
		<div class="clear"></div>
	</div>
</div>
<!--  -->
<?php }} ?>