<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 12:27:05
         compiled from "templates/default/index\module\promotion.php" */ ?>
<?php /*%%SmartyHeaderCode:301255a5d7f198d4a07-05636545%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca07c7bbfe03d2b3dc11dd87227ddb1a21fd00b6' => 
    array (
      0 => 'templates/default/index\\module\\promotion.php',
      1 => 1388952500,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '301255a5d7f198d4a07-05636545',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'promotion' => 0,
    'item' => 0,
    'S_ROOT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f199db74',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f199db74')) {function content_5a5d7f199db74($_smarty_tpl) {?>
<div class="block img_list" id="promotion">
	<div class="head"><span>促销商品</span><a href="<?php echo url(array('channel'=>'goods','promotion'=>1),$_smarty_tpl);?>
">更多&gt;&gt;</a></div>
	<div class="main">
		<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['promotion']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
		<div class="unit">
			<div class="img">
				<table>
					<tr>
						<td>
							<a href="<?php echo url(array('channel'=>'goods','id'=>$_smarty_tpl->tpl_vars['item']->value['goo_id']),$_smarty_tpl);?>
" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['S_ROOT']->value;?>
<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_x_img'];?>
" onload="picresize(this,130,130)"/></a>
						</td>
					</tr>
				</table>
			</div>
			<div class="word">
				<div class="title"><a href="<?php echo url(array('channel'=>'goods','id'=>$_smarty_tpl->tpl_vars['item']->value['goo_id']),$_smarty_tpl);?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['item']->value['goo_title'];?>
</a></div>
				<div class="market_price">市场价：<span>￥<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_market_price'];?>
元</span></div>
				<div class="shop_price">本店价：￥<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_shop_price'];?>
元</div>
			</div>
		</div>
		<?php } ?>
		<div class="clear"></div>
	</div>
</div><?php }} ?>