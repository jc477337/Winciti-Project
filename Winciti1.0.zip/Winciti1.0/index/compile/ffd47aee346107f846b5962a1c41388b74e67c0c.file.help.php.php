<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:50:03
         compiled from "templates/default/index\module\help.php" */ ?>
<?php /*%%SmartyHeaderCode:213575a5a0f31b85830-12429777%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ffd47aee346107f846b5962a1c41388b74e67c0c' => 
    array (
      0 => 'templates/default/index\\module\\help.php',
      1 => 1516092597,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '213575a5a0f31b85830-12429777',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5a0f31c85a4',
  'variables' => 
  array (
    'help_cat' => 0,
    'cat' => 0,
    'art_list' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5a0f31c85a4')) {function content_5a5a0f31c85a4($_smarty_tpl) {?>
<div class="block" id="help">
	<div class="head"><span>Help Center</span><a href="<?php echo url(array('channel'=>'help'),$_smarty_tpl);?>
">More&gt;&gt;</a></div>
	<div class="main">
		<?php  $_smarty_tpl->tpl_vars['cat'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cat']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['help_cat']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cat']->key => $_smarty_tpl->tpl_vars['cat']->value){
$_smarty_tpl->tpl_vars['cat']->_loop = true;
?>
		<div class="unit">
			<div><a href="<?php echo url(array('channel'=>'help','cat'=>$_smarty_tpl->tpl_vars['cat']->value['id']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['cat']->value['name'];?>
</a></div>
			<ul>
				<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['art_list']->value[$_smarty_tpl->tpl_vars['cat']->value['id']]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
				<li><a href="<?php echo url(array('channel'=>'help','id'=>$_smarty_tpl->tpl_vars['item']->value['art_id']),$_smarty_tpl);?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['art_title'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['item']->value['art_title'];?>
</a></li>
				<?php } ?>
			</ul>
		</div>
		<?php } ?>
		<div class="clear"></div>
	</div>
</div><?php }} ?>