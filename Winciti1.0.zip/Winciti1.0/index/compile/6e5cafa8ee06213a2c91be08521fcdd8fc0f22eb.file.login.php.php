<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:59:55
         compiled from "templates/default/index\module\login.php" */ ?>
<?php /*%%SmartyHeaderCode:49775a5d7f195c1b57-43237625%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6e5cafa8ee06213a2c91be08521fcdd8fc0f22eb' => 
    array (
      0 => 'templates/default/index\\module\\login.php',
      1 => 1516093148,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '49775a5d7f195c1b57-43237625',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f196a492',
  'variables' => 
  array (
    'global' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f196a492')) {function content_5a5d7f196a492($_smarty_tpl) {?>
<div class="block" id="login">
	<div class="head"><span>Login</span></div>
	<div class="main">
	<?php if (!$_smarty_tpl->tpl_vars['global']->value['user_id']){?>
		<form name="form_user_login" method="post" action="<?php echo url(array('entrance'=>$_smarty_tpl->tpl_vars['global']->value['entrance'],'channel'=>'info'),$_smarty_tpl);?>
">
			<input name="cmd" type="hidden" value="user_login"/>
			<table>
				<tr>
					<td class="l">帐号:</td>
					<td class="r"><input class="text" name="username" type="text" /></td>
				</tr>
				<tr>
					<td class="l">密码:</td>
					<td class="r"><input class="text" name="password" type="password" /></td>
				</tr>
				<tr>
					<td colspan="2">
						<input class="button" type="submit" value="登录" />&nbsp;&nbsp;
						<input class="button" type="button" value="注册" onclick="document.location.href='<?php echo url(array('entrance'=>$_smarty_tpl->tpl_vars['global']->value['entrance'],'channel'=>'user','mod'=>'register'),$_smarty_tpl);?>
'" />
					</td>
				</tr>
			</table>
		</form>
	<?php }else{ ?>
		<table class="link">
			<tr>
				<td><a href="<?php echo url(array('entrance'=>$_smarty_tpl->tpl_vars['global']->value['entrance'],'channel'=>'user','mod'=>'profile'),$_smarty_tpl);?>
">用户信息</a></td>
				<td><a href="<?php echo url(array('entrance'=>$_smarty_tpl->tpl_vars['global']->value['entrance'],'channel'=>'user','mod'=>'order_sheet'),$_smarty_tpl);?>
">我的订单</a></td>
			</tr>
			<tr>
				<td><a href="<?php echo url(array('entrance'=>$_smarty_tpl->tpl_vars['global']->value['entrance'],'channel'=>'user','mod'=>'message_sheet'),$_smarty_tpl);?>
">我的留言</a></td>
				<td><a href="<?php echo url(array('entrance'=>$_smarty_tpl->tpl_vars['global']->value['entrance'],'channel'=>'user','mod'=>'comment_sheet'),$_smarty_tpl);?>
">我的Comments</a></td>
			</tr>
			<tr>
				<td colspan="2"><a href="<?php echo url(array('entrance'=>$_smarty_tpl->tpl_vars['global']->value['entrance'],'channel'=>'user','mod'=>'logout'),$_smarty_tpl);?>
">Logout</a></td>
			</tr>
		</table>
	<?php }?>
	</div>
</div>
<!--  -->
<?php }} ?>