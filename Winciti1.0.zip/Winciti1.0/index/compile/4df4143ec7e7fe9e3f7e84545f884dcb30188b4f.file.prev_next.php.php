<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 18:17:41
         compiled from "templates/default/index\module\prev_next.php" */ ?>
<?php /*%%SmartyHeaderCode:172285a5d86fc6cb9f1-11095390%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4df4143ec7e7fe9e3f7e84545f884dcb30188b4f' => 
    array (
      0 => 'templates/default/index\\module\\prev_next.php',
      1 => 1516097851,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '172285a5d86fc6cb9f1-11095390',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d86fc78674',
  'variables' => 
  array (
    'prev_title' => 0,
    'prefix' => 0,
    'prev_id' => 0,
    'next_title' => 0,
    'next_id' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d86fc78674')) {function content_5a5d86fc78674($_smarty_tpl) {?>
<div id="prev_next">
	<div class="prev">Previous:<?php if ($_smarty_tpl->tpl_vars['prev_title']->value){?><a href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'id'=>$_smarty_tpl->tpl_vars['prev_id']->value),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['prev_title']->value;?>
</a><?php }else{ ?>Nothing<?php }?></div>
	<div class="next">Next:<?php if ($_smarty_tpl->tpl_vars['next_title']->value){?><a href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'id'=>$_smarty_tpl->tpl_vars['next_id']->value),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['next_title']->value;?>
</a><?php }else{ ?>Nothing<?php }?></div>
	<div class="clear"></div>
</div><?php }} ?>