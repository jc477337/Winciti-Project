<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 17:06:42
         compiled from "templates/default/index\module\goods_main.php" */ ?>
<?php /*%%SmartyHeaderCode:294145a5d7f63f345e0-97878769%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3ea1a851e913a1503dbfd6920c7398e756603509' => 
    array (
      0 => 'templates/default/index\\module\\goods_main.php',
      1 => 1516093594,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '294145a5d7f63f345e0-97878769',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f642e150',
  'variables' => 
  array (
    'show_sheet' => 0,
    'goods' => 0,
    'item' => 0,
    'S_ROOT' => 0,
    'global' => 0,
    'share_code' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f642e150')) {function content_5a5d7f642e150($_smarty_tpl) {?>
<?php if ($_smarty_tpl->tpl_vars['show_sheet']->value==1){?>
	<div class="block img_list">
		<?php echo $_smarty_tpl->getSubTemplate ("module/here.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

		<div class="main">
			<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['goods']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
			<div class="unit">
				<div class="img">
					<table>
						<tr>
							<td>
								<a href="<?php echo url(array('channel'=>'goods','id'=>$_smarty_tpl->tpl_vars['item']->value['goo_id']),$_smarty_tpl);?>
" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['S_ROOT']->value;?>
<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_x_img'];?>
" onload="picresize(this,300,300)"/></a>
							</td>
						</tr>
					</table>
				</div>
				<div class="word">
					<div class="title"><a href="<?php echo url(array('channel'=>'goods','id'=>$_smarty_tpl->tpl_vars['item']->value['goo_id']),$_smarty_tpl);?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['item']->value['goo_title'];?>
</a></div>
					<div class="market_price">市场价:<span>￥<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_market_price'];?>
元</span></div>
					<div class="shop_price">本店价:￥<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_shop_price'];?>
元</div>
				</div>
			</div>
			<?php } ?>
			<div class="clear"></div>
			<?php if (!$_smarty_tpl->tpl_vars['goods']->value){?><div class="not_found">NO Content</div><?php }?>
			<?php echo $_smarty_tpl->getSubTemplate ("module/page_link.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('page'=>$_smarty_tpl->tpl_vars['global']->value['page']), 0);?>

		</div>
	</div>
<?php }else{ ?>
	<div id="goods">
		<div class="info">
			<div class="l">
				<div class="img">
					<table>
						<tr>
							<td>
								<a href="<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_img'];?>
" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['S_ROOT']->value;?>
<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_img'];?>
" onload="picresize(this,300,300)"/></a>
							</td>
						</tr>
					</table>
				</div>
				<!--
				商品副图，二次开发中根据需要调用
				<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['goods']->value['more_img']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?><img src="<?php echo $_smarty_tpl->tpl_vars['S_ROOT']->value;?>
<?php echo $_smarty_tpl->tpl_vars['item']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_title'];?>
" /><?php } ?>
				-->
			</div>
			<div class="r">
				<div class="title"><?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_title'];?>
</div>
				<div class="sn">商品货号:<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_sn'];?>
</div>
				<div class="brand">商品品牌:测试品牌</div>
				<div class="market_price">市场价格:<span>￥<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_market_price'];?>
元</span></div>
				<div class="shop_price">本店售价:<span>￥<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_shop_price'];?>
元</span></div>
				<div class="hits">浏览次数:<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_hits'];?>
</div>
				<div class="number">商品库存:<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_number'];?>
</div>
				<div class="buy_num">购买数量:<input id="buy_num" type="text" value="1" /></div>
				<table>
					<tr>
						<td class="bt_row"><a onclick="add_to_cart(<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_id'];?>
)">加入购物车</a></td>
						<td class="bt_row"><a onclick="add_to_collection(<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_id'];?>
)">加入收藏夹</a></td>
						<td class="bt_row"><a onclick="show_box('share',300,100);">推荐给好友</a></td>
					</tr>
				</table>
			</div>
			<div class="clear"></div>
		</div>
		<div class="block">
			<div class="head"><span>Product attributes</span></div>
			<div class="main">
				<?php if ($_smarty_tpl->tpl_vars['goods']->value['goo_attribute']){?>
				<table class="goods_att">
					<tr>
						<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['goods']->value['att']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['item']->total= $_smarty_tpl->_count($_from);
 $_smarty_tpl->tpl_vars['item']->iteration=0;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['att']['index']=-1;
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
 $_smarty_tpl->tpl_vars['item']->iteration++;
 $_smarty_tpl->tpl_vars['item']->last = $_smarty_tpl->tpl_vars['item']->iteration === $_smarty_tpl->tpl_vars['item']->total;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['att']['index']++;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['att']['last'] = $_smarty_tpl->tpl_vars['item']->last;
?>
						<td width="15%"><?php echo $_smarty_tpl->tpl_vars['item']->value['name'];?>
:</td>
						<td width="35%"><?php echo $_smarty_tpl->tpl_vars['item']->value['value'];?>
</td>
						<?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['att']['index']%2==1&&!$_smarty_tpl->getVariable('smarty')->value['foreach']['att']['last']){?></tr><tr><?php }?>
						<?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['att']['index']%2==0&&$_smarty_tpl->getVariable('smarty')->value['foreach']['att']['last']){?>
						<td width="15%">&nbsp;</td>
						<td width="35%">&nbsp;</td>
						<?php }?>
						<?php } ?>
					</tr>
				</table>
				<?php }else{ ?>该商品暂未添加属性<?php }?>
			</div>
		</div>
		<div class="block">
			<div class="head"><span>Product Description</span></div>
			<div class="main goods_text">
				<?php echo $_smarty_tpl->tpl_vars['goods']->value['goo_text'];?>

			</div>
		</div>
		<?php echo $_smarty_tpl->getSubTemplate ("module/comment.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

	</div>
	<!-------------------------- BOX -------------------------->
	<div class="alert" id="share">
		<div class="head">
			<div class="title">推荐给好友</div>
			<div class="close" onclick="hide_box('share')">关闭</div>
		</div>
		<div class="share_main">
			<?php echo $_smarty_tpl->tpl_vars['share_code']->value;?>

		</div>
	</div>
	<!-------------------------- BOX -------------------------->
	
	<script language="javascript">
	function add_to_cart(id)
	{
		var buy_num = document.getElementById("buy_num").value;
		ajax("post","?/deal/","cmd=add_to_cart&id=" + id + "&buy_num=" + buy_num,
		function(data)
		{
			if(data == 1)
			{
				document.location.href = "?/flow/";
			}else if(data == 2){
				alert("对不起，该商品已经库存不足暂停销售。\n你现在要进行缺货登记来预订该商品吗？");
				document.location.href = "?/user/mod-booking_add/goods_id-" + id + "/";
			}
		});
	}
	function add_to_collection(id)
	{
		ajax("post","?/deal/","cmd=add_to_collection&id=" + id,
		function(data)
		{
			if(data == 0)
			{
				alert("由于您还没有登录，因此您还不能使用该功能");
			}else if(data == 1)
			{
				alert("该商品已经成功地加入了您的收藏夹");
			}else if(data == 2){
				alert("该商品已经存在于您的收藏夹中");
			}
		});
	}
	</script>
	
<?php }?>
<!--  -->
<?php }} ?>