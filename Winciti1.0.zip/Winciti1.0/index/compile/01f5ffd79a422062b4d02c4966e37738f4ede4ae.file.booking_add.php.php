<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 12:48:16
         compiled from "templates/default/index\module\user\booking_add.php" */ ?>
<?php /*%%SmartyHeaderCode:227055a5d841091b938-36005475%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '01f5ffd79a422062b4d02c4966e37738f4ede4ae' => 
    array (
      0 => 'templates/default/index\\module\\user\\booking_add.php',
      1 => 1515843478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '227055a5d841091b938-36005475',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'global' => 0,
    'goods_title' => 0,
    'boo_consignee' => 0,
    'boo_email' => 0,
    'boo_tel' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d84109f8ca',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d84109f8ca')) {function content_5a5d84109f8ca($_smarty_tpl) {?>
<div class="block">
	<div class="head"><span>添加缺货登记</span></div>
	<div class="main add_booking">
		<form name="form_add_booking" method="post" action="<?php echo url(array('channel'=>'user'),$_smarty_tpl);?>
">
			<input name="cmd" type="hidden" value="add_booking"/>
			<input name="goods_id" type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['global']->value['goods_id'];?>
"/>
			<table class="table">
				<tr>
					<td class="l">订购商品名：</td>
					<td class="r"><?php echo $_smarty_tpl->tpl_vars['goods_title']->value;?>
</td>
				</tr>
				<tr>
					<td class="l">订购数量：</td>
					<td class="r"><input class="text" name="number" type="text" /></td>
				</tr>
				<tr>
					<td class="l">订购描述：</td>
					<td class="r"><textarea name="text"></textarea></td>
				</tr>
				<tr>
					<td class="l">联系人：</td>
					<td class="r"><input class="text" name="consignee" type="text" value="<?php echo $_smarty_tpl->tpl_vars['boo_consignee']->value;?>
" /></td>
				</tr>
				<tr>
					<td class="l">电子邮件地址：</td>
					<td class="r"><input class="text" name="email" type="text" value="<?php echo $_smarty_tpl->tpl_vars['boo_email']->value;?>
" /></td>
				</tr>
				<tr>
					<td class="l">联系电话：</td>
					<td class="r"><input class="text" name="tel" type="text" value="<?php echo $_smarty_tpl->tpl_vars['boo_tel']->value;?>
" /></td>
				</tr>
				<tr>
					<td class="bt_row" colspan="2"><input class="button" type="button" onclick="submit_add_booking()" value="确认修改" /></td>
				</tr>
			</table>
		</form>
	</div>
</div>

<script language="javascript">
function submit_add_booking()
{
	var str = "";
	if(document.form_add_booking.number.value == ""){str += "-请输入您要订购的商品数量\n";}
	if(document.form_add_booking.text.value == ""){str += "-请输入您的订购描述信息\n";}
	if(document.form_add_booking.consignee.value == ""){str += "-请输入联系人姓名\n";}
	if(document.form_add_booking.email.value == ""){str += "-请输入联系人的电子邮件地址\n";}
	if(document.form_add_booking.tel.value == ""){str += "-请输入联系人的电话\n";}
	if(str != "")
	{
alert(str);
	}else{
		document.form_add_booking.submit();
	}
}
</script>

<!--  --><?php }} ?>