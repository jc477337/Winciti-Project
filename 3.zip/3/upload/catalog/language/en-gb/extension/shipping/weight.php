<?php
// Text
$_['text_title']  = 'Weight Based Shipping';
$_['text_weight'] = 'Weight:';