<?php

// Text

$_['text_footer']  = '<a href="http://www.jcub.com.au">JCU ICT2 Team 6</a> &copy; 2017-' . date('Y') . ' All Rights Reserved.';

$_['text_version'] = 'Version 1.5';