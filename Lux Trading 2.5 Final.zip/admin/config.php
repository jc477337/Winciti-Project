<?php
// HTTP
define('HTTP_SERVER', 'http://www.ljpacific.com.au/ecshop/2/upload/admin/');
define('HTTP_CATALOG', 'http://www.ljpacific.com.au/ecshop/2/upload/');

// HTTPS
define('HTTPS_SERVER', 'http://www.ljpacific.com.au/ecshop/2/upload/admin/');
define('HTTPS_CATALOG', 'http://www.ljpacific.com.au/ecshop/2/upload/');

// DIR
define('DIR_APPLICATION', '/home10/ljpacifi/public_html/ecshop/2/upload/admin/');
define('DIR_SYSTEM', '/home10/ljpacifi/public_html/ecshop/2/upload/system/');
define('DIR_IMAGE', '/home10/ljpacifi/public_html/ecshop/2/upload/image/');
define('DIR_LANGUAGE', '/home10/ljpacifi/public_html/ecshop/2/upload/admin/language/');
define('DIR_TEMPLATE', '/home10/ljpacifi/public_html/ecshop/2/upload/admin/view/template/');
define('DIR_CONFIG', '/home10/ljpacifi/public_html/ecshop/2/upload/system/config/');
define('DIR_CACHE', '/home10/ljpacifi/public_html/ecshop/2/upload/system/storage/cache/');
define('DIR_DOWNLOAD', '/home10/ljpacifi/public_html/ecshop/2/upload/system/storage/download/');
define('DIR_LOGS', '/home10/ljpacifi/public_html/ecshop/2/upload/system/storage/logs/');
define('DIR_MODIFICATION', '/home10/ljpacifi/public_html/ecshop/2/upload/system/storage/modification/');
define('DIR_UPLOAD', '/home10/ljpacifi/public_html/ecshop/2/upload/system/storage/upload/');
define('DIR_CATALOG', '/home10/ljpacifi/public_html/ecshop/2/upload/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'ljpacifi_team6');
define('DB_PASSWORD', 'plmokn0987');
define('DB_DATABASE', 'ljpacifi_team6');
define('DB_PORT', '3306');
define('DB_PREFIX', '');
