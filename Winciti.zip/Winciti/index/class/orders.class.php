<?php
class orders extends table
{
	public function __construct()
	{
		parent::__construct();
		$this->set_table(S_DB_PREFIX.'orders');
		$this->set_where("ord_lang = '".S_LANG."'");
		$this->set_order('ord_id');
	}
	
	public function get_status_name($val)
	{
		switch($val)
		{
			case 0: return '未付款';break;
			case 1: return '已付款';break;
			case 2: return '等待发货';break;
			case 3: return '已发货';break;
			case 4: return '交易成功';break;
		}
	}
	
	protected function deal($field,$val)
	{
		if($field == 'ord_price_total'){
			$val = sprintf('%.2f',$val);
		}
		return $val;
	}
}
//
?>