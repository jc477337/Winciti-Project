<?php
class payment extends table
{
	public function __construct()
	{
		parent::__construct();
		$this->set_table(S_DB_PREFIX.'payment');
		$this->set_where("pay_lang = '".S_LANG."'");
		$this->set_where('pay_show = 1');
		$this->set_order('pay_top');
		$this->set_order('pay_index');
		$this->set_order('pay_id','asc');
	}
	
	protected function deal($field,$val)
	{
		if($field == 'pay_price')
		{
			$val = sprintf('%.2f',$val);
		}
		return $val;
	}
}
//
?>