<?php
class consignee extends table
{
	public function __construct()
	{
		parent::__construct();
		$this->set_table(S_DB_PREFIX.'consignee');
		$this->set_where("con_lang = '".S_LANG."'");
	}
}
//
?>