<?php /* Smarty version Smarty-3.1.3, created on 2018-01-17 09:25:04
         compiled from "templates/default/index\module\page_link.php" */ ?>
<?php /*%%SmartyHeaderCode:48205a5d7f643a9d10-59844802%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e2842ea9d4e7d892313819f15e27665c4d444cd6' => 
    array (
      0 => 'templates/default/index\\module\\page_link.php',
      1 => 1516152302,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '48205a5d7f643a9d10-59844802',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f64632c8',
  'variables' => 
  array (
    'page_sum' => 0,
    'page' => 0,
    'prefix' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f64632c8')) {function content_5a5d7f64632c8($_smarty_tpl) {?>
<div class="page_link">
	<div class="in">
		<span>Total <?php echo $_smarty_tpl->tpl_vars['page_sum']->value;?>
 pages</span>
		<span>Current <?php echo $_smarty_tpl->tpl_vars['page']->value;?>
 page</span>
		<?php if ($_smarty_tpl->tpl_vars['page_sum']->value!=1){?>
		<a href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>1),$_smarty_tpl);?>
">frist</a>
		<?php if ($_smarty_tpl->tpl_vars['page']->value-1>0){?><a href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value-1),$_smarty_tpl);?>
">pre</a><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['page']->value-4>0){?><a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value-4),$_smarty_tpl);?>
">【<?php echo $_smarty_tpl->tpl_vars['page']->value-4;?>
】</a><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['page']->value-3>0){?><a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value-3),$_smarty_tpl);?>
">【<?php echo $_smarty_tpl->tpl_vars['page']->value-3;?>
】</a><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['page']->value-2>0){?><a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value-2),$_smarty_tpl);?>
">【<?php echo $_smarty_tpl->tpl_vars['page']->value-2;?>
】</a><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['page']->value-1>0){?><a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value-1),$_smarty_tpl);?>
">【<?php echo $_smarty_tpl->tpl_vars['page']->value-1;?>
】</a><?php }?>
		<a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value),$_smarty_tpl);?>
" style="color:#C00;">【<?php echo $_smarty_tpl->tpl_vars['page']->value;?>
】</a>
		<?php if ($_smarty_tpl->tpl_vars['page']->value+1<=$_smarty_tpl->tpl_vars['page_sum']->value){?><a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value+1),$_smarty_tpl);?>
">【<?php echo $_smarty_tpl->tpl_vars['page']->value+1;?>
】</a><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['page']->value+2<=$_smarty_tpl->tpl_vars['page_sum']->value){?><a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value+2),$_smarty_tpl);?>
">【<?php echo $_smarty_tpl->tpl_vars['page']->value+2;?>
】</a><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['page']->value+3<=$_smarty_tpl->tpl_vars['page_sum']->value){?><a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value+3),$_smarty_tpl);?>
">【<?php echo $_smarty_tpl->tpl_vars['page']->value+3;?>
】</a><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['page']->value+4<=$_smarty_tpl->tpl_vars['page_sum']->value){?><a class="num" href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value+4),$_smarty_tpl);?>
">【<?php echo $_smarty_tpl->tpl_vars['page']->value+4;?>
】</a><?php }?>
		<?php if ($_smarty_tpl->tpl_vars['page']->value+1<=$_smarty_tpl->tpl_vars['page_sum']->value){?><a href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value+1),$_smarty_tpl);?>
">next</a><?php }?>
		<a href="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page_sum']->value),$_smarty_tpl);?>
">last</a>
		<?php }?>
		<form id="form_jump" action="" method="get">
			<input type="hidden" name="url" value="<?php echo url(array('prefix'=>$_smarty_tpl->tpl_vars['prefix']->value,'page'=>$_smarty_tpl->tpl_vars['page']->value),$_smarty_tpl);?>
" />
			<input class="text" type="text" name="page" value="<?php echo $_smarty_tpl->tpl_vars['page']->value;?>
" />
			<input class="button" type="button" onclick="page_jump('<?php echo $_smarty_tpl->tpl_vars['page']->value;?>
')" value="GO"/>
		</form>
	</div>
</div>

<script language="javascript">
	function page_jump(val)
	{
		var obj = document.getElementById("form_jump");
		var url = obj.url.value;
		var page = obj.page.value;
		url = url.replace("/page-" + val + "/","/page-" + page + "/");
		document.location.href = url;
	}
</script>

<!--  --><?php }} ?>