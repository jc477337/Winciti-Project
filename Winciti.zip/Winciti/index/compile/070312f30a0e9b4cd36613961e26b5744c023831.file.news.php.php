<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:44:46
         compiled from "templates/default/index\module\news.php" */ ?>
<?php /*%%SmartyHeaderCode:252845a5d7f1981c688-18876602%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '070312f30a0e9b4cd36613961e26b5744c023831' => 
    array (
      0 => 'templates/default/index\\module\\news.php',
      1 => 1516092282,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '252845a5d7f1981c688-18876602',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f198c757',
  'variables' => 
  array (
    'news' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f198c757')) {function content_5a5d7f198c757($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'E:\wamp\www\oneb2c\smarty\plugins\modifier.date_format.php';
?>
<div class="block" id="news">
	<div class="head"><span>News</span></div>
	<div class="main">
		<ul>
			<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['news']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
			<li>
				<a href="<?php echo url(array('channel'=>'article','id'=>$_smarty_tpl->tpl_vars['item']->value['art_id']),$_smarty_tpl);?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['art_title'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['item']->value['short_title'];?>
</a>
				<span><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['item']->value['art_add_time'],"%Y-%m-%d");?>
</span>
				<div class="clear"></div>
			</li>
			<?php } ?>
		</ul>
	</div>
</div>
<!--  -->
<?php }} ?>