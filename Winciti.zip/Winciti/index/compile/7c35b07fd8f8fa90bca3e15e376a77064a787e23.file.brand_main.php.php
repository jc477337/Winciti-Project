<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 13:00:28
         compiled from "templates/default/index\module\brand_main.php" */ ?>
<?php /*%%SmartyHeaderCode:318405a5d86ecdaa670-54624525%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c35b07fd8f8fa90bca3e15e376a77064a787e23' => 
    array (
      0 => 'templates/default/index\\module\\brand_main.php',
      1 => 1388952500,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '318405a5d86ecdaa670-54624525',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'brand' => 0,
    'item' => 0,
    'S_ROOT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d86ece9243',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d86ece9243')) {function content_5a5d86ece9243($_smarty_tpl) {?>
<div class="block bra_sheet">
	<?php echo $_smarty_tpl->getSubTemplate ("module/here.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

	<div class="main">
		<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['brand']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
		<div class="unit">
			<div class="img">
				<table>
					<tr>
						<td>
							<a href="<?php echo url(array('channel'=>'goods','brand'=>$_smarty_tpl->tpl_vars['item']->value['bra_id']),$_smarty_tpl);?>
" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['S_ROOT']->value;?>
<?php echo $_smarty_tpl->tpl_vars['item']->value['bra_img'];?>
" onload="picresize(this,155,55)"/></a>
						</td>
					</tr>
				</table>
			</div>
			<div class="txt"><?php echo $_smarty_tpl->tpl_vars['item']->value['bra_text'];?>
</div>
		</div>
		<?php } ?>
	<div class="clear"></div>
	<?php if (!$_smarty_tpl->tpl_vars['brand']->value){?><div class="not_found">暂无内容</div><?php }?>
	</div>
</div><?php }} ?>