<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:59:50
         compiled from "templates/default/index\module\user\menu.php" */ ?>
<?php /*%%SmartyHeaderCode:237595a5d81bfb0dd40-62625324%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa0a309bb49983295ce3be82d9cc31f91ac8d70b' => 
    array (
      0 => 'templates/default/index\\module\\user\\menu.php',
      1 => 1516093000,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '237595a5d81bfb0dd40-62625324',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d81bfbbb16',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d81bfbbb16')) {function content_5a5d81bfbbb16($_smarty_tpl) {?>
<div id="user_menu">
	<ul>
		<li><a href="<?php echo url(array('channel'=>'user'),$_smarty_tpl);?>
">欢迎页</a></li>
		<li><a href="<?php echo url(array('channel'=>'user','mod'=>'profile'),$_smarty_tpl);?>
">用户信息</a></li>
		<li><a href="<?php echo url(array('channel'=>'user','mod'=>'order_sheet'),$_smarty_tpl);?>
">我的订单</a></li>
		<li><a href="<?php echo url(array('channel'=>'user','mod'=>'address_list'),$_smarty_tpl);?>
">收货地址</a></li>
		<li><a href="<?php echo url(array('channel'=>'user','mod'=>'collection_list'),$_smarty_tpl);?>
">我的收藏</a></li>
		<li><a href="<?php echo url(array('channel'=>'user','mod'=>'message_sheet'),$_smarty_tpl);?>
">我的留言</a></li>
		<li><a href="<?php echo url(array('channel'=>'user','mod'=>'comment_sheet'),$_smarty_tpl);?>
">我的Comments</a></li>
		<li><a href="<?php echo url(array('channel'=>'user','mod'=>'booking_sheet'),$_smarty_tpl);?>
">缺货登记</a></li>
		<li><a href="<?php echo url(array('channel'=>'user','mod'=>'account_sheet'),$_smarty_tpl);?>
">在线充值</a></li>
	</ul>
	<div class="bt_row"><a href="<?php echo url(array('channel'=>'user','mod'=>'logout'),$_smarty_tpl);?>
">退出系统</a></div>
</div><?php }} ?>