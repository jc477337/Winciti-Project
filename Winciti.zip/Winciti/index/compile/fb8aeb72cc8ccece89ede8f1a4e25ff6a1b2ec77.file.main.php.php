<?php /* Smarty version Smarty-3.1.3, created on 2018-01-13 21:52:49
         compiled from "templates/default/index\module\user\main.php" */ ?>
<?php /*%%SmartyHeaderCode:167915a5a0f319155b9-61677124%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fb8aeb72cc8ccece89ede8f1a4e25ff6a1b2ec77' => 
    array (
      0 => 'templates/default/index\\module\\user\\main.php',
      1 => 1388952500,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '167915a5a0f319155b9-61677124',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'show_info' => 0,
    'show_mod' => 0,
    'global' => 0,
    'file' => 0,
    'info_text' => 0,
    'link_href' => 0,
    'link_text' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5a0f319dfe9',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5a0f319dfe9')) {function content_5a5a0f319dfe9($_smarty_tpl) {?>
<?php if ($_smarty_tpl->tpl_vars['show_info']->value!=1){?>
	<?php if ($_smarty_tpl->tpl_vars['show_mod']->value=='register'){?>
		<?php echo $_smarty_tpl->getSubTemplate ("module/user/register.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

	<?php }elseif($_smarty_tpl->tpl_vars['show_mod']->value=='user_center'){?>
		<div id="left">
			<?php echo $_smarty_tpl->getSubTemplate ("module/user/menu.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

		</div>
		<div id="right" class="user_center">
			<?php $_smarty_tpl->tpl_vars['file'] = new Smarty_variable((('module/user/').($_smarty_tpl->tpl_vars['global']->value['mod'])).('.php'), null, 0);?>
			<?php echo $_smarty_tpl->getSubTemplate ($_smarty_tpl->tpl_vars['file']->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

		</div>
		<div class="clear"></div>
	<?php }else{ ?>
		<?php echo $_smarty_tpl->getSubTemplate ("module/user/login.php", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

	<?php }?>
<?php }else{ ?>
	<div class="block" id="info">
		<div class="head"><span>系统信息</span></div>
		<div class="main">
			<div><?php echo $_smarty_tpl->tpl_vars['info_text']->value;?>
</div>
			<a href="<?php echo $_smarty_tpl->tpl_vars['link_href']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['link_text']->value;?>
</a>
		</div>
	</div>
	<script language="javascript">
		interval = setInterval("document.location.href = '<?php echo $_smarty_tpl->tpl_vars['link_href']->value;?>
'",3000);
	</script>
<?php }?><?php }} ?>