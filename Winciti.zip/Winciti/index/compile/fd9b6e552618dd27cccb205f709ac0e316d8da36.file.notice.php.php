<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:41:47
         compiled from "templates/default/index\module\notice.php" */ ?>
<?php /*%%SmartyHeaderCode:33525a5d7f195a2730-02314102%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fd9b6e552618dd27cccb205f709ac0e316d8da36' => 
    array (
      0 => 'templates/default/index\\module\\notice.php',
      1 => 1516092072,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '33525a5d7f195a2730-02314102',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f195b960',
  'variables' => 
  array (
    'notice' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f195b960')) {function content_5a5d7f195b960($_smarty_tpl) {?>
<div class="block" id="notice">
	<div class="head"><span>Announcement</span></div>
	<div class="main">
		<?php echo $_smarty_tpl->tpl_vars['notice']->value;?>

	</div>
</div>
<!--  -->
<?php }} ?>