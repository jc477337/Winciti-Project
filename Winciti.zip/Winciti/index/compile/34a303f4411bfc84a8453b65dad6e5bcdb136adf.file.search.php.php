<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:43:43
         compiled from "templates/default/index\module\search.php" */ ?>
<?php /*%%SmartyHeaderCode:92385a5a0f318a96c0-55177689%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '34a303f4411bfc84a8453b65dad6e5bcdb136adf' => 
    array (
      0 => 'templates/default/index\\module\\search.php',
      1 => 1516092213,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '92385a5a0f318a96c0-55177689',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5a0f31909ea',
  'variables' => 
  array (
    'global' => 0,
    'search_cat' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5a0f31909ea')) {function content_5a5a0f31909ea($_smarty_tpl) {?>
<div id="search">
	<form id="form_search" method="post" action="<?php echo url(array('entrance'=>$_smarty_tpl->tpl_vars['global']->value['entrance'],'channel'=>'search'),$_smarty_tpl);?>
">
		<select name="cat">
			<option value="0">All Categories</option>
			<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['search_cat']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
			<option value="<?php echo $_smarty_tpl->tpl_vars['item']->value['cat_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['item']->value['cat_name'];?>
</option>
			<?php } ?>
		</select>
		<input class="text" name="key" type="text" maxlength="30" onkeydown="if(event.keyCode == 13)do_search();" />
		<input class="button" type="button" onclick="do_search()" value="Search" />
	</form>	
	<div class="clear"></div>
</div>
<!--  --><?php }} ?>