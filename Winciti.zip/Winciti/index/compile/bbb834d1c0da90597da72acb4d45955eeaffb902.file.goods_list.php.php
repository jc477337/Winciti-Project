<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:59:56
         compiled from "templates/default/index\module\goods_list.php" */ ?>
<?php /*%%SmartyHeaderCode:162975a5d7f19c2a625-32020698%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bbb834d1c0da90597da72acb4d45955eeaffb902' => 
    array (
      0 => 'templates/default/index\\module\\goods_list.php',
      1 => 1516093148,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '162975a5d7f19c2a625-32020698',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f19cef10',
  'variables' => 
  array (
    'best_goo_cat' => 0,
    'cat' => 0,
    'goods_list' => 0,
    'item' => 0,
    'S_ROOT' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f19cef10')) {function content_5a5d7f19cef10($_smarty_tpl) {?>
<?php  $_smarty_tpl->tpl_vars['cat'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cat']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['best_goo_cat']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cat']->key => $_smarty_tpl->tpl_vars['cat']->value){
$_smarty_tpl->tpl_vars['cat']->_loop = true;
?>
<div class="block img_list">
	<div class="head"><span><?php echo $_smarty_tpl->tpl_vars['cat']->value['cat_name'];?>
</span><a href="<?php echo url(array('channel'=>'goods','cat'=>$_smarty_tpl->tpl_vars['cat']->value['cat_id']),$_smarty_tpl);?>
">More&gt;&gt;</a></div>
	<div class="main">
		<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['goods_list']->value[$_smarty_tpl->tpl_vars['cat']->value['cat_id']]; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
		<div class="unit">
			<div class="img">
				<table>
					<tr>
						<td>
							<a href="<?php echo url(array('channel'=>'goods','id'=>$_smarty_tpl->tpl_vars['item']->value['goo_id']),$_smarty_tpl);?>
" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['S_ROOT']->value;?>
<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_x_img'];?>
" onload="picresize(this,130,130)"/></a>
						</td>
					</tr>
				</table>
			</div>
			<div class="word">
				<div class="title"><a href="<?php echo url(array('channel'=>'goods','id'=>$_smarty_tpl->tpl_vars['item']->value['goo_id']),$_smarty_tpl);?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['item']->value['goo_title'];?>
</a></div>
				<div class="market_price">市场价:<span>￥<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_market_price'];?>
元</span></div>
				<div class="shop_price">本店价:￥<?php echo $_smarty_tpl->tpl_vars['item']->value['goo_shop_price'];?>
元</div>
			</div>
		</div>
		<?php } ?>
		<div class="clear"></div>
	</div>
</div>
<?php } ?>
<!--  --><?php }} ?>