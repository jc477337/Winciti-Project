<?php /* Smarty version Smarty-3.1.3, created on 2018-01-16 16:50:48
         compiled from "templates/default/index\module\link.php" */ ?>
<?php /*%%SmartyHeaderCode:187345a5d7f19cfd489-86272325%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '08c97e3213e88c2e8708656a00f6ecfdfb6ca177' => 
    array (
      0 => 'templates/default/index\\module\\link.php',
      1 => 1516092642,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '187345a5d7f19cfd489-86272325',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.3',
  'unifunc' => 'content_5a5d7f19d9145',
  'variables' => 
  array (
    'img_link' => 0,
    'item' => 0,
    'word_link' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a5d7f19d9145')) {function content_5a5d7f19d9145($_smarty_tpl) {?>
<div class="block" id="link">
	<div class="head"><span>Links</span></div>
	<div class="main">
		<?php if ($_smarty_tpl->tpl_vars['img_link']->value){?>
			<div class="img">
				<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['img_link']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
				<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['lin_url'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['lin_title'];?>
" target="_blank"><img src="<?php echo $_smarty_tpl->tpl_vars['item']->value['lin_img'];?>
"/></a>
				<?php } ?>
				<div class="clear"></div>
			</div>
		<?php }?>
		<?php if ($_smarty_tpl->tpl_vars['word_link']->value){?>
			<div class="word">
				<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['word_link']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
$_smarty_tpl->tpl_vars['item']->_loop = true;
?>
				<a href="<?php echo $_smarty_tpl->tpl_vars['item']->value['lin_url'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['item']->value['lin_title'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['item']->value['lin_word'];?>
</a>
				<?php } ?>
			</div>
		<?php }?>
	</div>
</div>
<!--  -->
<?php }} ?>