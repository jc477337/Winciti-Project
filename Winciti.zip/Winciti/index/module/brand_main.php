<?php
function module_brand_main()
{
	global $smarty;
	$obj = new brand();
	$obj->set_field('bra_id,bra_name,bra_img,bra_text');
	$smarty->assign('brand',$obj->get_list());
}
//
?>