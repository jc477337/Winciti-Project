<?php
function module_goods_list()
{
	global $smarty;
	$obj = new cat_goo();
	$obj->set_where('cat_best = 1');
	$best_cat = $obj->get_list();
	$goo_list = array();
	$list_len = get_varia('index_img_list_len');
	for($i = 0; $i < count($best_cat); $i ++)
	{
		$cat = $best_cat[$i]['cat_id'];
		$family = implode(',',get_cat_family('cat_goo',$cat));
		$obj = new goods();
		$obj->set_field('goo_id,goo_title,goo_x_img,goo_market_price,goo_shop_price');
		$obj->set_where("goo_cat_id in ($family)");
		$obj->set_page_size($list_len ? $list_len : 10);
		$list = $obj->get_list();
		for($j = 0; $j < count($list); $j ++)
		{
			$list[$j]['short_title'] = cut_str($list[$j]['goo_title'],11);
		}
		$goo_list[$cat] = $list;
		unset($obj);
	}
	$smarty->assign('best_goo_cat',$best_cat);	
	$smarty->assign('goods_list',$goo_list);
}
//
?>