<?php
function module_goods_tree()
{
	global $smarty;
	$obj = new cat_goo();
	$smarty->assign('goods_tree',$obj->get_tree());
}
//
?>