<?php
function module_download_main()
{
	global $global,$smarty;
	$obj = new article();
	$obj->set_field('art_title,art_text,art_add_time,art_url');
	$obj->set_art_type('download');
	$obj->set_page_size(5);
	$obj->set_page_num($global['page']);
	$smarty->assign('download',$obj->get_article());
	if($global['id'] == 0) set_link($obj->get_page_sum());
}
//
?>