<?php
function module_contact()
{
	global $smarty;
	$obj = new contact_model;
	$smarty->assign('contact',$obj->get_contact());
}
//
?>