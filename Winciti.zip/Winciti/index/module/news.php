<?php
function module_news()
{
	global $smarty;
	$family = implode(',',get_cat_family('cat_art',1));
	$list_len = get_varia('index_art_list_len');
	$obj = new article();
	$obj->set_field('art_id,art_title,art_add_time');
	$obj->set_where("art_cat_id not in ($family)");
	$obj->set_page_size($list_len ? $list_len : 6);
	$list = $obj->get_list();
	for($j = 0; $j < count($list); $j ++)
	{
		$list[$j]['short_title'] = cut_str($list[$j]['art_title'],20);
	}
	$smarty->assign('news',$list);
}
//
?>