<?php
function module_logout()
{
	global $global,$smarty;
	unset_cookie('user_username');
	unset_cookie('user_password');
	$info_text = '您已经退出用户中心';
	$link_text = '重新登录';
	$smarty->assign('show_info',1);
	$smarty->assign('info_text',$info_text);
	$smarty->assign('link_href',url(array('channel'=>'user')));
	$smarty->assign('link_text',$link_text);
}
//
?>