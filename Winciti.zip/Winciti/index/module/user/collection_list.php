<?php
function module_collection_list()
{
	global $global,$smarty;
	$obj = new collection();
	$obj->set_table(S_DB_PREFIX.'goods');
	$obj->set_field('col_id,goo_id,goo_title,goo_market_price,goo_shop_price');
	$obj->set_where('col_user_id = '.$global['user_id']);
	$obj->set_where('col_goods_id = goo_id');
	$smarty->assign('collection',$obj->get_list());
}
//
?>