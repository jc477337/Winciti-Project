<?php
function module_order_info()
{
	global $global,$smarty;
	$obj = new orders();
	$obj->set_where('ord_id = '.$global['id']);
	$one = $obj->get_one();
	if(count($one) > 0)
	{
		$goods = get_goods_info(rawurldecode($one['ord_goods_json']));
		$one['user_name'] = get_data('users',$one['ord_user_id'],'use_username');
		$one['status_name'] = $obj->get_status_name($one['ord_status']);
		$one['payment_code'] = get_data('payment',$one['ord_payment_id'],'pay_code');
		$smarty->assign('order',$one);
	}else{
		rhs_error();
	}
}
function get_goods_info($json)
{
	global $smarty;
	$goods = array();
	$shop_total = 0;
	if($json != '' && $json != 'null')
	{
		if($arr = json_decode($json,true))
		{
			$obj = new goods();
			for($i = 0;$i < count($arr);$i ++)
			{
				$obj->set_where('');
				$obj->set_where('goo_show = 1');
				$obj->set_where('goo_id = '.$arr[$i]['goo_id']);
				$list = $obj->get_list();
				for($j = 0; $j < count($list); $j ++)
				{
					$list[$j]['goo_title'] = cut_str($list[$j]['goo_title'],11);
				}
				$goods[$i] = $list[0];
				$goods[$i]['number'] = $arr[$i]['number'];
				$goods[$i]['subtotal'] = sprintf('%.2f',$goods[$i]['goo_shop_price'] * $arr[$i]['number']);
				$shop_total += $goods[$i]['subtotal'];
			}
		}
	}
	$smarty->assign('goods',$goods);
	$smarty->assign('shop_total',sprintf('%.2f',$shop_total));
}
//
?>