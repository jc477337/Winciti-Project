<?php
function module_account_sheet()
{
	global $global,$smarty;
	$obj = new account();
	$obj->set_where('acc_user_id = '.$global['user_id']);
	$obj->set_page_size(10);
	$obj->set_page_num($global['page']);
	$sheet = $obj->get_sheet();
	set_link($obj->get_page_sum());
	for($i = 0; $i < count($sheet); $i ++)
	{
		$sheet[$i]['status_name'] = $obj->get_status_name($sheet[$i]['acc_status']);
	}
	$smarty->assign('account',$sheet);
}
//
?>