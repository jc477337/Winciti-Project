<?php
function module_order_sheet()
{
	global $global,$smarty;
	$obj = new orders();
	$obj->set_field('ord_id,ord_sn,ord_add_time,ord_price_total,ord_status');
	$obj->set_where('ord_user_id = '.$global['user_id']);
	$obj->set_page_size(15);
	$obj->set_page_num($global['page']);
	$sheet = $obj->get_sheet();
	for($i = 0; $i < count($sheet); $i ++)
	{
		$sheet[$i]['status_name'] = $obj->get_status_name($sheet[$i]['ord_status']);
	}
	set_link($obj->get_page_sum());
	$smarty->assign('orders',$sheet);
}
//
?>