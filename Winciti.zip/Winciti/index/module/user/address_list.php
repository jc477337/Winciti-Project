<?php
function module_address_list()
{
	global $global,$smarty;
	$arr = array();
	if($global['user_id'] != 0)
	{
		$obj = new consignee();
		$obj->set_where('con_user_id = '.$global['user_id']);
		$arr =$obj->get_list();
		$obj = new region();
		for($i = 0; $i < count($arr); $i ++)
		{
			$region[$i] = explode('|',$arr[$i]['con_region']);
			
			$obj->set_where('');
			$obj->set_where('reg_parent_id = 0');
			$arr[$i]['region_1'] = $obj->get_option(0,$region[$i][0]);
			
			$obj->set_where('');
			$obj->set_where('reg_parent_id = ' . $region[$i][0]);
			$arr[$i]['region_2'] = $obj->get_option($region[$i][0],$region[$i][1]);
			
			$obj->set_where('');
			$obj->set_where('reg_parent_id = ' . $region[$i][1]);
			$arr[$i]['region_3'] = $obj->get_option($region[$i][1],$region[$i][2]);
		}
		$obj->set_where('');
		$obj->set_where('reg_parent_id = 0');
		$con_region = $obj->get_option();
		$obj = new users();
		$obj->set_where('use_id = '.$global['user_id']);
		$one = $obj->get_one();
		if(count($one) > 0)
		{
			$con_consignee = $one['use_real_name'];
			$con_email = $one['use_email'];
			$con_address = $one['use_address'];
			$con_tel = $one['use_tel'];
		}else{
			rhs_error();
		}
	}else{
		rhs_error();
	}
	$smarty->assign('consignee',$arr);
	$smarty->assign('con_region',$con_region);
	$smarty->assign('con_consignee',$con_consignee);
	$smarty->assign('con_email',$con_email);
	$smarty->assign('con_address',$con_address);
	$smarty->assign('con_tel',$con_tel);
}
//
?>