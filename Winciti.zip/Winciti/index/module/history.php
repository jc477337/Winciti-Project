<?php
function module_history()
{
	global $smarty;
	$history = get_cookie('history');
	if($history != '')	
	{
		$history = substr($history,1,-1);
		$arr = explode('|',$history);
		
		$list = array();
		$obj = new goods();
		$obj->set_field('goo_id,goo_title,goo_x_img,goo_market_price,goo_shop_price');
		for($i = 0;$i < count($arr);$i ++)
		{
			$obj->set_where('');
			$obj->set_where('goo_show = 1');
			$obj->set_where('goo_id = '.$arr[$i]);
			$one = $obj->get_one();
			if(count($one))
			{
				$one['goo_title'] = cut_str($one['goo_title'],15);
				$list[$i] = $one;
			}
		}
		$smarty->assign('history',$list);
	}else{
		$smarty->assign('history',array());
	}
}
//
?>