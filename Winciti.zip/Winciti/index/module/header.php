<?php
function module_header()
{
	global $smarty;
	$obj = new menu();
	$obj->set_where("men_type = 'header'");
	$obj->set_field('men_name,men_url');
	$smarty->assign('nav',$obj->get_list());
	
	$obj = new cat_goo();
	$obj->set_where('cat_parent_id = 0');
	$smarty->assign('search_cat',$obj->get_list());
	
	$val = get_varia('hot_search');
	$smarty->assign('hot_search',explode('|',$val));
	
	//头部购物车信息
	$cart = array();
	$cart_number = 0;
	$cart_price = 0;
	$json = get_cart_json();
	if($json != '' && $json != 'null')
	{
		if($arr = json_decode($json,true))
		{
			$obj = new goods();
			$obj->set_field('goo_id,goo_shop_price');
			for($i = 0;$i < count($arr);$i ++)
			{
				$id = key($arr);
				$obj->set_where('');
				$obj->set_where('goo_show = 1');
				$obj->set_where("goo_id = $id");
				$one = $obj->get_one();
				if(count($one))
				{
					$cart_number += $arr[$id];
					$cart_price += sprintf('%.2f',$one['goo_shop_price'] * $arr[$id]);
				}else{
					$cart_number += 0;
					$cart_price += 0;
				}
				next($arr);
			}
		}
	}
	$smarty->assign('cart_number',$cart_number);
	$smarty->assign('cart_price',sprintf('%.2f',$cart_price));
}
//
?>