<?php
function module_goods_main()
{
	global $global,$smarty;
	$global['brand'] = get_global('brand');
	$global['price'] = get_global('price');
	$global['sell'] = get_global('sell');
	$goo_promotion = get_global('promotion');
	$goo_best = get_global('best');
	$goo_new = get_global('new');
	$goo_hot = get_global('hot');
	$prefix = 'goods';
	
	if(!$global['id'])
	{
		$list_len = get_varia('img_list_len');
		$obj = new goods();
		$obj->set_field('goo_id,goo_title,goo_x_img,goo_market_price,goo_shop_price');
		if($global['cat'])
		{
			$family = implode(',',get_cat_family('cat_goo',$global['cat']));
			$obj->set_where("goo_cat_id in ($family)");
			$prefix .= '/cat-' . $global['cat'];
		}
		if($global['brand'])
		{
			$obj->set_where('goo_brand_id = '.$global['brand']);
			$prefix .= '/brand-' . $global['brand'];
		}
		if($goo_promotion)
		{
			$obj->set_where('goo_promotion = 1');
			$prefix .= '/promotion-1';
		}elseif($goo_best){
			$obj->set_where('goo_best = 1');
			$prefix .= '/best-1';
		}elseif($goo_new){
			$obj->set_where('goo_new = 1');
			$prefix .= '/new-1';
		}elseif($goo_hot){
			$obj->set_where('goo_hot = 1');
			$prefix .= '/hot-1';
		}
		
		if($global['price'] == 'desc')
		{
			$obj->set_order('goo_shop_price');
		}elseif($global['price'] == 'asc'){
			$obj->set_order('goo_shop_price','asc');
		}	
		if($global['sell'] == 'desc')
		{
			$obj->set_order('goo_sell');
		}elseif($global['sell'] == 'asc'){
			$obj->set_order('goo_sell','asc');
		}
		
		$obj->set_page_size($list_len ? $list_len : 30);
		$obj->set_page_num($global['page']);
		$sheet = $obj->get_sheet();
		for($i = 0; $i < count($sheet); $i ++)
		{
			$sheet[$i]['goo_title'] = cut_str($sheet[$i]['goo_title'],11);
		}
		set_link($obj->get_page_sum());
		$smarty->assign('show_sheet',1);
		$smarty->assign('goods',$sheet);
	}else{
		$obj = new goods();
		$obj->set_field('goo_id,goo_title,goo_sn,goo_img,goo_more_img,goo_number,goo_text,goo_market_price,goo_shop_price,goo_number,goo_sell,goo_attribute,goo_hits');
		$obj->set_where('goo_id = '.$global['id']);
		$goods = $obj->get_one();
		
		$goods['more_img'] = array();
		if($goods['goo_more_img'] != '')
		{
			$goods['more_img'] = explode('|',$goods['goo_more_img']);
		}
		
		$goods['att'] = array();
		$obj = new attribute();
		$att_arr = $obj->get_list();
		$goods['att'] = get_att_list($att_arr,$goods['goo_attribute']);
		
		add_to_history($goods['goo_id']);
		
		$obj = new varia();
		$smarty->assign('share_code',$obj->get_value('share_code',true));
		
		$smarty->assign('goods',$goods);
		$smarty->assign('show_sheet',0);
	}
	$smarty->assign('prefix',$prefix);
}
function add_to_history($id)
{
	$val = get_cookie('history');
	if($val == '')
	{
		$val = '|' . $id . '|';
	}elseif(strpos($val,'|' . $id . '|') === false){
		$val = substr($val,1,-1);
		$arr = explode('|',$val);
		$val = '|';
		for($i = 0; $i < count($arr) && $i < 7; $i ++)
		{
			$val .= $arr[$i] . '|';
		}
		$val = '|' . $id . $val;
	}
	set_cookie('history',$val);
}
//
?>