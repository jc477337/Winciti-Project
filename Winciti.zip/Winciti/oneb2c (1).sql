-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 年 01 月 17 日 06:00
-- 服务器版本: 5.5.24-log
-- PHP 版本: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `oneb2c`
--

-- --------------------------------------------------------

--
-- 表的结构 `one_account`
--

CREATE TABLE IF NOT EXISTS `one_account` (
  `acc_id` int(11) NOT NULL AUTO_INCREMENT,
  `acc_user_id` int(11) DEFAULT '0',
  `acc_type` varchar(50) DEFAULT NULL,
  `acc_sn` varchar(50) DEFAULT NULL,
  `acc_name` varchar(50) DEFAULT NULL,
  `acc_increase` int(11) DEFAULT '0',
  `acc_amount` double DEFAULT '0',
  `acc_add_time` int(11) DEFAULT '0',
  `acc_edit_time` int(11) DEFAULT '0',
  `acc_status` int(11) DEFAULT '0',
  PRIMARY KEY (`acc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `one_admin`
--

CREATE TABLE IF NOT EXISTS `one_admin` (
  `adm_id` int(11) NOT NULL AUTO_INCREMENT,
  `adm_username` varchar(50) DEFAULT NULL,
  `adm_password` varchar(50) DEFAULT NULL,
  `adm_grade` int(11) DEFAULT '0',
  `adm_power` text,
  `adm_prev_login` int(11) DEFAULT '0',
  `adm_last_login` int(11) DEFAULT '0',
  PRIMARY KEY (`adm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `one_admin`
--

INSERT INTO `one_admin` (`adm_id`, `adm_username`, `adm_password`, `adm_grade`, `adm_power`, `adm_prev_login`, `adm_last_login`) VALUES
(1, 'admin', '96e79218965eb72c92a549dd5a330112', 1, 'all', 1516080961, 1516081684);

-- --------------------------------------------------------

--
-- 表的结构 `one_article`
--

CREATE TABLE IF NOT EXISTS `one_article` (
  `art_id` int(11) NOT NULL AUTO_INCREMENT,
  `art_cat_id` int(11) DEFAULT '0',
  `art_lang` varchar(50) DEFAULT 'none',
  `art_type` varchar(50) DEFAULT NULL,
  `art_title` varchar(250) DEFAULT NULL,
  `art_text` text,
  `art_author` varchar(50) DEFAULT NULL,
  `art_add_time` int(11) DEFAULT '0',
  `art_img` varchar(250) DEFAULT NULL,
  `art_keywords` varchar(250) DEFAULT NULL,
  `art_description` varchar(250) DEFAULT NULL,
  `art_hits` int(11) DEFAULT '0',
  `art_url` varchar(250) DEFAULT NULL,
  `art_best` int(11) DEFAULT '0',
  `art_top` int(11) DEFAULT '0',
  `art_index` int(11) DEFAULT '0',
  `art_show` int(11) DEFAULT '1',
  PRIMARY KEY (`art_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `one_article`
--

INSERT INTO `one_article` (`art_id`, `art_cat_id`, `art_lang`, `art_type`, `art_title`, `art_text`, `art_author`, `art_add_time`, `art_img`, `art_keywords`, `art_description`, `art_hits`, `art_url`, `art_best`, `art_top`, `art_index`, `art_show`) VALUES
(1, 10, 'zh-cn', NULL, 'About Us', '<p style="text-align:center;">It is a introduction about Winciti Trading Pty Ltd</p>', 'Jason', 1516088302, NULL, '网站关键字', '网站描述', 0, NULL, 0, 0, 0, 1),
(2, 7, 'zh-cn', NULL, 'FAQ', '<p>Question1：sdfsadfas</p><p>Answer：werwrwerwe</p><p>Question2：sdfsadfas</p><p>Answer：werwrwerwe</p><p>Question3：sdfsadfas</p><p>Answer：werwrwerwe</p><p>Question4：sdfsadfas</p><p>Answer：werwrwerwe</p><p>Question5：sdfsadfas</p><p>Answer：werwrwerwe</p>', '', 1516088415, NULL, '网站关键字', '网站描述', 0, NULL, 0, 0, 0, 1),
(3, 10, 'zh-cn', NULL, 'Contact Us', '<p style="text-align:center;"><span style="font-size:16px;line-height:115%;background-color:#FFFFFF;color:#000000;">Winciti TradingPty Ltd</span></p><p style="text-align:center;"><span style="font-size:16px;line-height:115%;color:red"><br /></span></p><p style="text-align:center;"><span style="font-size:16px;line-height:115%;background-color:#FFFFFF;color:#000000;">Address</span><span style="font-size:16px;line-height:115%;font-family:宋体;background-color:#FFFFFF;color:#000000;">：</span><span style="font-size:16px;line-height:115%;background-color:#FFFFFF;color:#000000;">2/30 LensworthSt, Coopers Plains, QLD Australia 4108 </span></p><p style="text-align:center;"><span style="font-size:16px;line-height:115%;font-family:宋体;background-color:#FFFFFF;color:#000000;">E-mail：</span><span style="font-size:16px;line-height:115%;color:red"><a href="mailto:Jason@luxholdings.com.au" style="background-color:#000000;text-decoration:underline;"><span style="font-size:16px;line-height:115%;background-color:#FFFFFF;color:#000000;">Jason@luxholdings.com.au</span></a></span></p><p style="text-align:center;"><span style="font-size:16px;line-height:115%;font-family:宋体;background-color:#FFFFFF;color:#000000;">Contact Number：</span><span style="font-size:16px;line-height:115%;background-color:#FFFFFF;color:#000000;">+61 406618166 &nbsp; </span></p><p style="text-align:center;"><span style="font-size:16px;line-height:115%;background-color:#FFFFFF;color:#000000;">24*7 </span><span style="font-size:16px;line-height:115%;font-family:宋体;background-color:#FFFFFF;color:#000000;">Hotline：</span><span style="font-size:16px;line-height:115%;background-color:#FFFFFF;color:#000000;">+61 3345 4590</span></p>', 'Jason', 1516088522, NULL, '网站关键字', '网站描述', 0, NULL, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_attribute`
--

CREATE TABLE IF NOT EXISTS `one_attribute` (
  `att_id` int(11) NOT NULL AUTO_INCREMENT,
  `att_cat_id` int(11) DEFAULT '0',
  `att_lang` varchar(50) DEFAULT 'none',
  `att_code` varchar(50) DEFAULT NULL,
  `att_name` varchar(50) DEFAULT NULL,
  `att_top` int(11) DEFAULT '0',
  `att_index` int(11) DEFAULT '0',
  `att_show` int(11) DEFAULT '1',
  PRIMARY KEY (`att_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `one_booking`
--

CREATE TABLE IF NOT EXISTS `one_booking` (
  `boo_id` int(11) NOT NULL AUTO_INCREMENT,
  `boo_user_id` int(11) DEFAULT '0',
  `boo_goods_id` int(11) DEFAULT '0',
  `boo_lang` varchar(50) DEFAULT 'none',
  `boo_number` int(11) DEFAULT '0',
  `boo_text` text,
  `boo_consignee` varchar(50) DEFAULT NULL,
  `boo_email` varchar(50) DEFAULT NULL,
  `boo_tel` varchar(50) DEFAULT NULL,
  `boo_add_time` int(11) DEFAULT '0',
  `boo_note` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`boo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `one_brand`
--

CREATE TABLE IF NOT EXISTS `one_brand` (
  `bra_id` int(11) NOT NULL AUTO_INCREMENT,
  `bra_lang` varchar(50) DEFAULT 'none',
  `bra_name` varchar(100) DEFAULT NULL,
  `bra_img` varchar(250) DEFAULT NULL,
  `bra_text` text,
  `bra_url` varchar(250) DEFAULT NULL,
  `bra_top` int(11) DEFAULT '0',
  `bra_index` int(11) DEFAULT '0',
  `bra_show` int(11) DEFAULT '1',
  PRIMARY KEY (`bra_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `one_brand`
--

INSERT INTO `one_brand` (`bra_id`, `bra_lang`, `bra_name`, `bra_img`, `bra_text`, `bra_url`, `bra_top`, `bra_index`, `bra_show`) VALUES
(1, 'zh-cn', 'Utena', '', '', 'www.utena.co.jp/', 0, 0, 1),
(2, 'zh-cn', 'Lion', '', '', 'www.lion.co.jp/', 0, 0, 1),
(3, 'zh-cn', 'Kao', '', '', 'www.kao.co.jp/', 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_cat_art`
--

CREATE TABLE IF NOT EXISTS `one_cat_art` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_parent_id` int(11) DEFAULT '0',
  `cat_lang` varchar(50) DEFAULT 'none',
  `cat_name` varchar(100) DEFAULT NULL,
  `cat_template` varchar(50) DEFAULT NULL,
  `cat_best` int(11) DEFAULT '0',
  `cat_top` int(11) DEFAULT '0',
  `cat_index` int(11) DEFAULT '0',
  `cat_show` int(11) DEFAULT '1',
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `one_cat_art`
--

INSERT INTO `one_cat_art` (`cat_id`, `cat_parent_id`, `cat_lang`, `cat_name`, `cat_template`, `cat_best`, `cat_top`, `cat_index`, `cat_show`) VALUES
(1, 0, 'zh-cn', 'HELP', NULL, 0, 0, 0, 1),
(2, 1, 'zh-cn', 'New Customer', NULL, 0, 0, 0, 1),
(3, 1, 'zh-cn', 'Payment', NULL, 0, 0, 0, 1),
(4, 1, 'zh-cn', 'Purchase Guide', NULL, 0, 0, 0, 1),
(5, 1, 'zh-cn', 'Delivery', NULL, 0, 0, 0, 1),
(6, 1, 'zh-cn', 'Policy', NULL, 0, 0, 0, 1),
(7, 1, 'zh-cn', 'Questions', NULL, 0, 0, 0, 1),
(8, 0, 'zh-cn', 'class1', NULL, 0, 0, 0, 1),
(9, 0, 'zh-cn', 'class2', NULL, 0, 0, 0, 1),
(10, 0, 'zh-cn', 'about us', NULL, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_cat_goo`
--

CREATE TABLE IF NOT EXISTS `one_cat_goo` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_parent_id` int(11) DEFAULT '0',
  `cat_lang` varchar(50) DEFAULT 'none',
  `cat_name` varchar(100) DEFAULT NULL,
  `cat_template` varchar(50) DEFAULT NULL,
  `cat_best` int(11) DEFAULT '0',
  `cat_top` int(11) DEFAULT '0',
  `cat_index` int(11) DEFAULT '0',
  `cat_show` int(11) DEFAULT '1',
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `one_cat_goo`
--

INSERT INTO `one_cat_goo` (`cat_id`, `cat_parent_id`, `cat_lang`, `cat_name`, `cat_template`, `cat_best`, `cat_top`, `cat_index`, `cat_show`) VALUES
(1, 0, 'zh-cn', 'Japan Product', NULL, 1, 0, 0, 1),
(2, 1, 'zh-cn', 'Baby and Mother', NULL, 1, 0, 0, 1),
(3, 1, 'zh-cn', 'Beauty', NULL, 1, 0, 0, 1),
(4, 1, 'zh-cn', 'Daily Care', NULL, 1, 0, 0, 1),
(5, 1, 'zh-cn', 'xxxxx', NULL, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_collection`
--

CREATE TABLE IF NOT EXISTS `one_collection` (
  `col_id` int(11) NOT NULL AUTO_INCREMENT,
  `col_user_id` int(11) DEFAULT '0',
  `col_goods_id` int(11) DEFAULT '0',
  `col_lang` varchar(50) DEFAULT 'none',
  `col_add_time` int(11) DEFAULT '0',
  PRIMARY KEY (`col_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `one_comment`
--

CREATE TABLE IF NOT EXISTS `one_comment` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `com_user_id` int(11) DEFAULT '0',
  `com_lang` varchar(50) DEFAULT 'none',
  `com_type` varchar(50) DEFAULT NULL,
  `com_page_id` int(11) DEFAULT '0',
  `com_email` varchar(50) DEFAULT NULL,
  `com_text` text,
  `com_reply` text,
  `com_rank` int(11) DEFAULT '0',
  `com_add_time` int(11) DEFAULT '0',
  `com_show` int(11) DEFAULT '1',
  PRIMARY KEY (`com_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `one_consignee`
--

CREATE TABLE IF NOT EXISTS `one_consignee` (
  `con_id` int(11) NOT NULL AUTO_INCREMENT,
  `con_user_id` int(11) DEFAULT '0',
  `con_lang` varchar(50) DEFAULT 'none',
  `con_region` varchar(50) DEFAULT NULL,
  `con_consignee` varchar(50) DEFAULT NULL,
  `con_email` varchar(50) DEFAULT NULL,
  `con_address` varchar(250) DEFAULT NULL,
  `con_zipcode` varchar(50) DEFAULT NULL,
  `con_tel` varchar(50) DEFAULT NULL,
  `con_mobile` varchar(50) DEFAULT NULL,
  `con_building` varchar(50) DEFAULT NULL,
  `con_best_time` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`con_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `one_goods`
--

CREATE TABLE IF NOT EXISTS `one_goods` (
  `goo_id` int(11) NOT NULL AUTO_INCREMENT,
  `goo_cat_id` int(11) DEFAULT '0',
  `goo_lang` varchar(50) DEFAULT 'none',
  `goo_title` varchar(250) DEFAULT NULL,
  `goo_sn` varchar(50) DEFAULT NULL,
  `goo_img` varchar(250) DEFAULT NULL,
  `goo_x_img` varchar(250) DEFAULT NULL,
  `goo_more_img` text,
  `goo_text` text,
  `goo_market_price` double DEFAULT '0',
  `goo_shop_price` double DEFAULT '0',
  `goo_brand_id` int(11) DEFAULT '0',
  `goo_number` int(11) DEFAULT '0',
  `goo_sell` int(11) DEFAULT '0',
  `goo_url` varchar(250) DEFAULT NULL,
  `goo_attribute` text,
  `goo_keywords` varchar(250) DEFAULT NULL,
  `goo_description` varchar(250) DEFAULT NULL,
  `goo_hits` int(11) DEFAULT '0',
  `goo_add_time` int(11) DEFAULT '0',
  `goo_promotion` int(11) DEFAULT '0',
  `goo_new` int(11) DEFAULT '0',
  `goo_best` int(11) DEFAULT '0',
  `goo_hot` int(11) DEFAULT '0',
  `goo_top` int(11) DEFAULT '0',
  `goo_index` int(11) DEFAULT '0',
  `goo_show` int(11) DEFAULT '1',
  PRIMARY KEY (`goo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `one_goods`
--

INSERT INTO `one_goods` (`goo_id`, `goo_cat_id`, `goo_lang`, `goo_title`, `goo_sn`, `goo_img`, `goo_x_img`, `goo_more_img`, `goo_text`, `goo_market_price`, `goo_shop_price`, `goo_brand_id`, `goo_number`, `goo_sell`, `goo_url`, `goo_attribute`, `goo_keywords`, `goo_description`, `goo_hits`, `goo_add_time`, `goo_promotion`, `goo_new`, `goo_best`, `goo_hot`, `goo_top`, `goo_index`, `goo_show`) VALUES
(3, 4, 'zh-cn', '花王KAO蒸汽眼罩无香 14枚 Kao Megrhythm Steam Eye Mask Unscented 14 pcs', '4901301229069 ', 'images/goods/20180116/2.jpg', 'images/goods/20180116/x_2.jpg', '', '<p><span style="font-family:arial, sans-serif;font-size:16px;background-color:#ffffff;">The eye mask which warms the eye that continued acting with comfortable steam. </span><br style="box-sizing:inherit;font-family:arial, sans-serif;font-size:16px;background-color:#ffffff;" /><span style="font-family:arial, sans-serif;font-size:16px;background-color:#ffffff;">Comfortable steam of approximately 40 degrees Celsius lasts around ten minutes and surrounds the important eyes and eye easily. </span></p>', 20, 19, 3, 100, 0, NULL, '%5B%5D', '网站关键字', '网站描述', 0, 1516082776, 0, 1, 0, 0, 0, 0, 1),
(2, 3, 'zh-cn', '佑天兰 果冻面膜 双重玻尿酸-红色 UTENA PREMIUM PURESA GOLDEN JELLY MASK -- HYALURONIC ACID', '4901234299214 ', 'images/goods/20180116/4901234299214.jpg', 'images/goods/20180116/x_4901234299214.jpg', '', '<table width="680" style="width:618px;"><tbody style="box-sizing:inherit;"><tr style="box-sizing:inherit;"><td style="box-sizing:inherit;padding:0px;margin:0px;"><span style="font-size:12px;font-family:メイリオ;box-sizing:inherit;">Golden Jul prescription balance formulated with moisturizing your skin&#39;s moisture oil (amino acids and ceramides).<br style="box-sizing:inherit;" />Combine to soften the booster function skin beauty liquid jelly mask 1 sheet per combination of 33 g.<br style="box-sizing:inherit;" />Free prescription 6 (synthetic fragrances, colorants, mineral oil, alcohol, animal-derived ingredients, UV absorbers free).<br style="box-sizing:inherit;" />Slaps and mask care take 20-30 minutes. A subtle scent of natural herbs (use of natural essential oils).<br style="box-sizing:inherit;" /><br style="box-sizing:inherit;" />Weight: 33 g x 3</span></td></tr></tbody></table>', 12.5, 11.88, 1, 100, 0, NULL, '%5B%5D', '网站关键字', '网站描述', 0, 1516082979, 1, 1, 1, 1, 1, 0, 1),
(4, 2, 'zh-cn', 'Merries L540花王乐而雅大号尿不湿（9-14）Kg Merries Nappies Japan Version Size L 54PK (L54)', '4901301230881 ', 'images/goods/20180116/3.jpg', 'images/goods/20180116/x_3.jpg', '', '<p>Triple layered &quot;air-through&quot; design keeps it as fresh as when you first put it on and protects the skin from bunching, which can cause rashes. </p><p>&quot;Soft fit&quot; is easy on the abdomen and suitable for any body type. </p><p>The raised gathers fit snugly around the thighs to prevent leakage from the soft poo.</p>', 25, 23.75, 3, 10, 0, NULL, '%5B%5D', '网站关键字', '网站描述', 0, 1516082967, 0, 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_link`
--

CREATE TABLE IF NOT EXISTS `one_link` (
  `lin_id` int(11) NOT NULL AUTO_INCREMENT,
  `lin_lang` varchar(50) DEFAULT 'none',
  `lin_word` varchar(50) DEFAULT NULL,
  `lin_url` varchar(250) DEFAULT NULL,
  `lin_img` varchar(250) DEFAULT NULL,
  `lin_title` varchar(50) DEFAULT NULL,
  `lin_top` int(11) DEFAULT '0',
  `lin_index` int(11) DEFAULT '0',
  `lin_show` int(11) DEFAULT '1',
  PRIMARY KEY (`lin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `one_link`
--

INSERT INTO `one_link` (`lin_id`, `lin_lang`, `lin_word`, `lin_url`, `lin_img`, `lin_title`, `lin_top`, `lin_index`, `lin_show`) VALUES
(3, 'zh-cn', 'Facebook', 'http://www.facebook.com', 'http://www.arthotelnoba.com/wp-content/themes/ibis-style-template/images/icon-facebook-black.svg', '', 0, 2, 1),
(4, 'zh-cn', 'Twitter', 'https://twitter.com/', 'https://cdn.worldvectorlogo.com/logos/twitter.svg', '', 0, 1, 1),
(5, 'zh-cn', 'Flickr', 'https://www.flickr.com/', 'http://balseros.miami.edu/images/icons/flickr.svg', '', 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_menu`
--

CREATE TABLE IF NOT EXISTS `one_menu` (
  `men_id` int(11) NOT NULL AUTO_INCREMENT,
  `men_lang` varchar(50) DEFAULT 'none',
  `men_type` varchar(50) DEFAULT NULL,
  `men_name` varchar(100) DEFAULT NULL,
  `men_url` varchar(250) DEFAULT NULL,
  `men_top` int(11) DEFAULT '0',
  `men_index` int(11) DEFAULT '0',
  `men_show` int(11) DEFAULT '1',
  PRIMARY KEY (`men_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=61 ;

--
-- 转存表中的数据 `one_menu`
--

INSERT INTO `one_menu` (`men_id`, `men_lang`, `men_type`, `men_name`, `men_url`, `men_top`, `men_index`, `men_show`) VALUES
(1, 'zh-cn', 'header', 'Home', 'index/', 0, 0, 1),
(59, 'zh-cn', 'header', 'Contact us', 'article/id-3/', 0, 0, 1),
(6, 'zh-cn', 'header', 'Products', 'goods/', 0, 0, 1),
(7, 'zh-cn', 'header', 'News', 'article/', 0, 0, 1),
(58, 'zh-cn', 'header', 'About us', 'article/id-1/', 0, 0, 1),
(9, 'zh-cn', 'header', 'VIP Area', 'user/', 0, 0, 1),
(10, 'zh-cn', 'header', 'Customer Comments', 'message/', 0, 0, 1),
(11, 'zh-cn', 'footer', 'Home', 'index/', 0, 0, 1),
(12, 'zh-cn', 'footer', 'All Product', 'goods/', 0, 0, 1),
(13, 'zh-cn', 'footer', 'News', 'article/', 0, 0, 1),
(14, 'zh-cn', 'footer', 'Brands Area', 'brand/', 0, 0, 1),
(15, 'zh-cn', 'footer', 'VIP Area', 'user/', 0, 0, 1),
(16, 'zh-cn', 'footer', 'Customer Comments', 'message/', 0, 0, 1),
(17, 'none', 'admin_header', '商城设置', 'basic/mod-basic_info/', 0, 0, 1),
(18, 'none', 'admin_header', '商品管理', 'goods/mod-sheet/', 0, 0, 1),
(19, 'none', 'admin_header', '订单管理', 'business/mod-order_sheet/', 0, 0, 1),
(20, 'none', 'admin_header', '用户互动', 'service/mod-user_sheet/', 0, 0, 1),
(21, 'none', 'admin_header', '文章管理', 'article/mod-sheet/', 0, 0, 1),
(22, 'none', 'admin_header', '文件管理', 'file/mod-pic_lists/', 0, 0, 1),
(23, 'none', 'admin_header', '网站设置', 'site/mod-site_set/', 0, 0, 1),
(24, 'none', 'admin_basic', '基本信息', 'basic/mod-basic_info/', 0, 0, 1),
(25, 'none', 'admin_basic', '配送方式', 'basic/mod-shipping_list/', 0, 0, 1),
(26, 'none', 'admin_basic', '配送范围', 'basic/mod-region_list/', 0, 0, 1),
(27, 'none', 'admin_basic', '支付方式', 'basic/mod-payment_list/', 0, 0, 1),
(28, 'none', 'admin_basic', '财务管理', 'basic/mod-account_sheet/', 0, 0, 1),
(29, 'none', 'admin_goods', '商品列表', 'goods/mod-sheet/', 0, 0, 1),
(30, 'none', 'admin_goods', '添加商品', 'goods/mod-add/', 0, 0, 1),
(31, 'none', 'admin_goods', '商品分类', 'goods/mod-cat_list/', 0, 0, 1),
(32, 'none', 'admin_goods', '商品品牌', 'goods/mod-brand_list/', 0, 0, 1),
(33, 'none', 'admin_goods', '商品属性', 'goods/mod-att_list/', 0, 0, 1),
(34, 'none', 'admin_business', '订单列表', 'business/mod-order_sheet/', 0, 0, 1),
(35, 'none', 'admin_business', '缺货登记', 'business/mod-booking_sheet/', 0, 0, 1),
(36, 'none', 'admin_service', '用户管理', 'service/mod-user_sheet/', 0, 0, 1),
(37, 'none', 'admin_service', '留言管理', 'service/mod-message_sheet/', 0, 0, 1),
(38, 'none', 'admin_service', '评论管理', 'service/mod-comment_sheet/', 0, 0, 1),
(39, 'none', 'admin_service', '网站公告', 'service/mod-notice/', 0, 0, 1),
(40, 'none', 'admin_service', '在线客服', 'service/mod-online/', 0, 0, 1),
(41, 'none', 'admin_service', '用户协议', 'service/mod-agreement/', 0, 0, 1),
(42, 'none', 'admin_article', '文章列表', 'article/mod-sheet/', 0, 0, 1),
(43, 'none', 'admin_article', '添加文章', 'article/mod-add/', 0, 0, 1),
(44, 'none', 'admin_article', '文章分类', 'article/mod-cat_list/', 0, 0, 1),
(46, 'none', 'admin_file', '图片管理', 'file/mod-pic_lists/', 0, 0, 1),
(47, 'none', 'admin_file', '焦点图片', 'file/mod-focus_list/', 0, 0, 1),
(50, 'none', 'admin_site', '网站设置', 'site/mod-site_set/', 0, 0, 1),
(51, 'none', 'admin_site', '导航管理', 'site/mod-nav_list/', 0, 0, 1),
(53, 'none', 'admin_site', '模块启闭', 'site/mod-show_set/', 0, 0, 1),
(55, 'none', 'admin_site', '管理员帐号', 'site/mod-admin_list/', 0, 0, 1),
(56, 'none', 'admin_site', '友情链接', 'site/mod-link_list/', 0, 0, 1),
(57, 'none', 'admin_site', '其它设置', 'site/mod-other/', 0, 0, 1),
(60, 'zh-cn', 'header', 'FAQ', 'help/id-2/', 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_message`
--

CREATE TABLE IF NOT EXISTS `one_message` (
  `mes_id` int(11) NOT NULL AUTO_INCREMENT,
  `mes_user_id` int(11) DEFAULT '0',
  `mes_lang` varchar(50) DEFAULT 'none',
  `mes_type` varchar(50) DEFAULT NULL,
  `mes_email` varchar(50) DEFAULT NULL,
  `mes_title` varchar(100) DEFAULT NULL,
  `mes_text` text,
  `mes_reply` text,
  `mes_add_time` int(11) DEFAULT '0',
  `mes_show` int(11) DEFAULT '1',
  PRIMARY KEY (`mes_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `one_message`
--

INSERT INTO `one_message` (`mes_id`, `mes_user_id`, `mes_lang`, `mes_type`, `mes_email`, `mes_title`, `mes_text`, `mes_reply`, `mes_add_time`, `mes_show`) VALUES
(1, 1, 'zh-cn', '留言', 'aaaaaa@qq.com', 'asfdsdf', 'asdfasdfasdfasdf', NULL, 1516077940, 1),
(2, 2, 'zh-cn', '留言', '174985159@qq.com', '123', '123 this comments', NULL, 1516085241, 1),
(3, 2, 'zh-cn', '留言', '174985159@qq.com', '321', '32112321312313', NULL, 1516086909, 1),
(4, 0, 'zh-cn', '留言', '撒大声地', '是的弗格森', '豆腐干豆腐', NULL, 1516088772, 0);

-- --------------------------------------------------------

--
-- 表的结构 `one_orders`
--

CREATE TABLE IF NOT EXISTS `one_orders` (
  `ord_id` int(11) NOT NULL AUTO_INCREMENT,
  `ord_user_id` int(11) DEFAULT '0',
  `ord_lang` varchar(50) DEFAULT 'none',
  `ord_sn` varchar(50) DEFAULT NULL,
  `ord_goods_json` text,
  `ord_region` varchar(50) DEFAULT NULL,
  `ord_consignee` varchar(50) DEFAULT NULL,
  `ord_email` varchar(50) DEFAULT NULL,
  `ord_address` varchar(250) DEFAULT NULL,
  `ord_zipcode` varchar(50) DEFAULT NULL,
  `ord_tel` varchar(50) DEFAULT NULL,
  `ord_mobile` varchar(50) DEFAULT NULL,
  `ord_building` varchar(50) DEFAULT NULL,
  `ord_best_time` varchar(50) DEFAULT NULL,
  `ord_message` text,
  `ord_note` text,
  `ord_shipping_id` int(11) DEFAULT '0',
  `ord_shipping_name` varchar(50) DEFAULT NULL,
  `ord_payment_id` int(11) DEFAULT '0',
  `ord_payment_name` varchar(50) DEFAULT NULL,
  `ord_price_json` text,
  `ord_price_total` double DEFAULT '0',
  `ord_express_no` varchar(50) DEFAULT NULL,
  `ord_add_time` int(11) DEFAULT '0',
  `ord_pay_time` int(11) DEFAULT '0',
  `ord_shipping_time` int(11) DEFAULT '0',
  `ord_status` int(11) DEFAULT '0',
  PRIMARY KEY (`ord_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `one_orders`
--

INSERT INTO `one_orders` (`ord_id`, `ord_user_id`, `ord_lang`, `ord_sn`, `ord_goods_json`, `ord_region`, `ord_consignee`, `ord_email`, `ord_address`, `ord_zipcode`, `ord_tel`, `ord_mobile`, `ord_building`, `ord_best_time`, `ord_message`, `ord_note`, `ord_shipping_id`, `ord_shipping_name`, `ord_payment_id`, `ord_payment_name`, `ord_price_json`, `ord_price_total`, `ord_express_no`, `ord_add_time`, `ord_pay_time`, `ord_shipping_time`, `ord_status`) VALUES
(1, 1, 'zh-cn', '180116124731233', '%5B%7B%22goo_id%22%3A%221%22%2C%22goo_title%22%3A%22%5Cu5546%5Cu54c1%5Cu6d4b%5Cu8bd5%5Cu4e00%22%2C%22goo_x_img%22%3A%22images%5C%2Fno_img.gif%22%2C%22goo_market_price%22%3A%222.00%22%2C%22goo_shop_price%22%3A%221.00%22%2C%22goo_add_time%22%3A%221516078018%22%2C%22goo_number%22%3A%221%22%2C%22number%22%3A1%2C%22subtotal%22%3A%221.00%22%7D%5D', '一级一|二级一|三级一', 'aaaaaa', 'aaaaaa@qq.com', 'aaaaaa', '', 'aaaaaa', '', '', '', '', NULL, 4, '市内快递', 2, '网银在线', '%7B%22shipping%22%3A6%2C%22payment%22%3A0%2C%22shop_total%22%3A1%2C%22market_total%22%3A2%7D', 7, NULL, 1516078074, 0, 0, 0),
(2, 1, 'zh-cn', '180116124855825', '%5B%7B%22goo_id%22%3A%221%22%2C%22goo_title%22%3A%22%5Cu5546%5Cu54c1%5Cu6d4b%5Cu8bd5%5Cu4e00%22%2C%22goo_x_img%22%3A%22images%5C%2Fno_img.gif%22%2C%22goo_market_price%22%3A%222.00%22%2C%22goo_shop_price%22%3A%221.00%22%2C%22goo_add_time%22%3A%221516078114%22%2C%22goo_number%22%3A%2210000%22%2C%22number%22%3A1%2C%22subtotal%22%3A%221.00%22%7D%5D', '一级一|二级一|三级一', 'aaaaaa', 'aaaaaa@qq.com', 'aaaaaa', '', 'aaaaaa', '', '', '', '', NULL, 4, '市内快递', 3, '货到付款', '%7B%22shipping%22%3A6%2C%22payment%22%3A5%2C%22shop_total%22%3A1%2C%22market_total%22%3A2%7D', 12, NULL, 1516078149, 0, 0, 0),
(3, 1, 'zh-cn', '180116125055940', '%5B%7B%22goo_id%22%3A%221%22%2C%22goo_title%22%3A%22%5Cu5546%5Cu54c1%5Cu6d4b%5Cu8bd5%5Cu4e00%22%2C%22goo_x_img%22%3A%22images%5C%2Fno_img.gif%22%2C%22goo_market_price%22%3A%222.00%22%2C%22goo_shop_price%22%3A%221.00%22%2C%22goo_add_time%22%3A%221516078114%22%2C%22goo_number%22%3A%229999%22%2C%22number%22%3A1%2C%22subtotal%22%3A%221.00%22%7D%5D', '一级一|二级一|三级一', 'aaaaaa', 'aaaaaa@qq.com', 'aaaaaa', '', 'aaaaaa', '', '', '', '', NULL, 4, '市内快递', 4, '线下银行转账', '%7B%22shipping%22%3A6%2C%22payment%22%3A0%2C%22shop_total%22%3A1%2C%22market_total%22%3A2%7D', 7, NULL, 1516078265, 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `one_payment`
--

CREATE TABLE IF NOT EXISTS `one_payment` (
  `pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_lang` varchar(50) DEFAULT 'none',
  `pay_code` varchar(50) DEFAULT NULL,
  `pay_name` varchar(100) DEFAULT NULL,
  `pay_price` double DEFAULT '0',
  `pay_text` text,
  `pay_config` text,
  `pay_top` int(11) DEFAULT '0',
  `pay_index` int(11) DEFAULT '0',
  `pay_show` int(11) DEFAULT '1',
  PRIMARY KEY (`pay_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `one_payment`
--

INSERT INTO `one_payment` (`pay_id`, `pay_lang`, `pay_code`, `pay_name`, `pay_price`, `pay_text`, `pay_config`, `pay_top`, `pay_index`, `pay_show`) VALUES
(1, 'zh-cn', 'system', '余额支付', 0, '余额支付描述', '', 0, 0, 1),
(3, 'zh-cn', 'cod', '货到付款', 5, '货到付款描述', '', 0, 0, 1),
(4, 'zh-cn', NULL, '线下银行转账', 0, '线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述线下银行转账描述', '', 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_picture`
--

CREATE TABLE IF NOT EXISTS `one_picture` (
  `pic_id` int(11) NOT NULL AUTO_INCREMENT,
  `pic_lang` varchar(50) DEFAULT 'none',
  `pic_type` varchar(50) DEFAULT NULL,
  `pic_title` varchar(50) DEFAULT NULL,
  `pic_path` varchar(250) DEFAULT NULL,
  `pic_url` varchar(250) DEFAULT NULL,
  `pic_site` varchar(50) DEFAULT NULL,
  `pic_text` text,
  `pic_add_time` int(11) DEFAULT '0',
  `pic_top` int(11) DEFAULT '0',
  `pic_index` int(11) DEFAULT '0',
  `pic_show` int(11) DEFAULT '1',
  PRIMARY KEY (`pic_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `one_picture`
--

INSERT INTO `one_picture` (`pic_id`, `pic_lang`, `pic_type`, `pic_title`, `pic_path`, `pic_url`, `pic_site`, `pic_text`, `pic_add_time`, `pic_top`, `pic_index`, `pic_show`) VALUES
(1, 'zh-cn', 'focus', '焦点图片', 'images/focus_2.jpg', 'index.php', 'default', NULL, 0, 0, 0, 1),
(2, 'zh-cn', 'focus', '焦点图片', 'images/focus_1.jpg', 'index.php', 'default', NULL, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_region`
--

CREATE TABLE IF NOT EXISTS `one_region` (
  `reg_id` int(11) NOT NULL AUTO_INCREMENT,
  `reg_parent_id` int(11) DEFAULT '0',
  `reg_lang` varchar(50) DEFAULT 'none',
  `reg_name` varchar(50) DEFAULT NULL,
  `reg_top` int(11) DEFAULT '0',
  `reg_index` int(11) DEFAULT '0',
  `reg_show` int(11) DEFAULT '1',
  PRIMARY KEY (`reg_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `one_region`
--

INSERT INTO `one_region` (`reg_id`, `reg_parent_id`, `reg_lang`, `reg_name`, `reg_top`, `reg_index`, `reg_show`) VALUES
(1, 0, 'zh-cn', 'Queenland', 0, 0, 1),
(2, 0, 'zh-cn', 'New South Wales', 0, 0, 1),
(3, 0, 'zh-cn', 'Victoria', 0, 0, 1),
(4, 1, 'zh-cn', 'Brisbane', 0, 0, 1),
(5, 1, 'zh-cn', 'Gold Coast', 0, 0, 1),
(6, 1, 'zh-cn', 'Sunshine Coast', 0, 0, 1),
(7, 2, 'zh-cn', 'Southport', 0, 0, 1),
(8, 2, 'zh-cn', 'Nerang', 0, 0, 1),
(9, 2, 'zh-cn', 'Robina', 0, 0, 1),
(10, 4, 'zh-cn', 'Sunnybank', 0, 0, 1),
(11, 4, 'zh-cn', 'Sunnybank Hills', 0, 0, 1),
(12, 4, 'zh-cn', 'Chermside', 0, 0, 1),
(13, 3, 'zh-cn', 'Melbourne', 0, 0, 1),
(14, 13, 'zh-cn', 'Box Hill', 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_shipping`
--

CREATE TABLE IF NOT EXISTS `one_shipping` (
  `shi_id` int(11) NOT NULL AUTO_INCREMENT,
  `shi_lang` varchar(50) DEFAULT 'none',
  `shi_name` varchar(100) DEFAULT NULL,
  `shi_price` double DEFAULT '0',
  `shi_text` text,
  `shi_top` int(11) DEFAULT '0',
  `shi_index` int(11) DEFAULT '0',
  `shi_show` int(11) DEFAULT '1',
  PRIMARY KEY (`shi_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `one_shipping`
--

INSERT INTO `one_shipping` (`shi_id`, `shi_lang`, `shi_name`, `shi_price`, `shi_text`, `shi_top`, `shi_index`, `shi_show`) VALUES
(4, 'zh-cn', '市内快递', 6, '市内快递描述', 0, 0, 1),
(5, 'zh-cn', '运费到付', 0, '运费到付描述', 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `one_users`
--

CREATE TABLE IF NOT EXISTS `one_users` (
  `use_id` int(11) NOT NULL AUTO_INCREMENT,
  `use_username` varchar(50) DEFAULT NULL,
  `use_password` varchar(50) DEFAULT NULL,
  `use_real_name` varchar(50) DEFAULT NULL,
  `use_email` varchar(50) DEFAULT NULL,
  `use_tel` varchar(50) DEFAULT NULL,
  `use_phone` varchar(50) DEFAULT NULL,
  `use_address` varchar(250) DEFAULT NULL,
  `use_money` double DEFAULT '0',
  `use_birthday` int(11) DEFAULT '0',
  `use_sex` int(11) DEFAULT '0',
  `use_reg_time` int(11) DEFAULT '0',
  `use_prev_login` int(11) DEFAULT '0',
  `use_last_login` int(11) DEFAULT '0',
  `use_question` varchar(50) DEFAULT NULL,
  `use_answer` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`use_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `one_users`
--

INSERT INTO `one_users` (`use_id`, `use_username`, `use_password`, `use_real_name`, `use_email`, `use_tel`, `use_phone`, `use_address`, `use_money`, `use_birthday`, `use_sex`, `use_reg_time`, `use_prev_login`, `use_last_login`, `use_question`, `use_answer`) VALUES
(1, 'aaaaaa', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'aaaaaa', 'aaaaaa@qq.com', 'aaaaaa', NULL, 'aaaaaa', 0, 0, 0, 1516077501, 1516077873, 1516079811, NULL, NULL),
(2, '123123', '4297f44b13955235245b2497399d7a93', 'jyl', '174985159@qq.com', '0406618166', NULL, '123', 0, 0, 0, 1516085216, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `one_varia`
--

CREATE TABLE IF NOT EXISTS `one_varia` (
  `var_id` int(11) NOT NULL AUTO_INCREMENT,
  `var_lang` varchar(50) DEFAULT 'none',
  `var_name` varchar(50) DEFAULT NULL,
  `var_value` varchar(250) DEFAULT NULL,
  `var_text` text,
  PRIMARY KEY (`var_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=68 ;

--
-- 转存表中的数据 `one_varia`
--

INSERT INTO `one_varia` (`var_id`, `var_lang`, `var_name`, `var_value`, `var_text`) VALUES
(1, 'zh-cn', 'site_title', 'Winciti', NULL),
(2, 'zh-cn', 'site_name', 'Winciti Trading Pty Ltd', NULL),
(3, 'none', 'site_domain', 'localhost', NULL),
(4, 'zh-cn', 'site_record', '', NULL),
(5, 'none', 'site_record_url', '', NULL),
(6, 'zh-cn', 'site_tech', '', NULL),
(7, 'none', 'site_tech_url', '', NULL),
(8, 'zh-cn', 'site_keywords', 'test', NULL),
(9, 'zh-cn', 'site_description', 'test', NULL),
(10, 'zh-cn', 'title', 'goods{v}Products{v}10', NULL),
(11, 'zh-cn', 'title', 'article{v}Articles{v}10', NULL),
(12, 'zh-cn', 'title', 'message{v}Message{v}10', NULL),
(13, 'zh-cn', 'title', 'brand{v}Brand{v}10', NULL),
(14, 'zh-cn', 'title', 'help{v}Help Center{v}10', NULL),
(15, 'zh-cn', 'title', 'search{v}Search Results{v}10', NULL),
(16, 'none', 'statistical_code', NULL, ''),
(17, 'none', 'share_code', NULL, ''),
(18, 'zh-cn', 'notice', NULL, '<p><span style="font-family:arial;background-color:#ffffff;">Announcement</span></p>'),
(19, 'zh-cn', 'service_code', NULL, 'Online service'),
(20, 'zh-cn', 'user_agreement', NULL, 'User Agreement'),
(21, 'none', 'languages', 'zh-cn{v}index.php{v}admin.php{v}LAN{v}LAN', NULL),
(22, 'none', 'languages', 'en-us{v}en.php{v}en_admin.php{v}英文{v}English', NULL),
(23, 'none', 'index_img_list_len', '10', NULL),
(24, 'none', 'index_promotion_len', '10', NULL),
(25, 'none', 'index_best_goods_len', '10', NULL),
(26, 'none', 'index_new_goods_len', '10', NULL),
(27, 'none', 'index_hot_goods_len', '10', NULL),
(28, 'none', 'index_art_list_len', '6', NULL),
(29, 'none', 'index_help_list_len', '5', NULL),
(30, 'none', 'img_list_len', '30', NULL),
(31, 'none', 'art_list_len', '20', NULL),
(33, 'none', 'x_img_width', '130', NULL),
(34, 'none', 'x_img_height', '130', NULL),
(35, 'none', 'single_page_static', '0', NULL),
(36, 'none', 'safe_admin_login_hours', '1', NULL),
(37, 'none', 'safe_admin_login_times', '10000', NULL),
(38, 'none', 'safe_user_login_hours', '1', NULL),
(39, 'none', 'safe_user_login_times', '20000', NULL),
(40, 'none', 'safe_register_hours', '1', NULL),
(41, 'none', 'safe_register_times', '30000', NULL),
(42, 'none', 'safe_message_hours', '1', NULL),
(43, 'none', 'safe_message_times', '30000', NULL),
(44, 'none', 'safe_comment_hours', '1', NULL),
(45, 'none', 'safe_comment_times', '20000', NULL),
(46, 'none', 'safe_booking_hours', '1', NULL),
(47, 'none', 'safe_booking_times', '20000', NULL),
(48, 'none', 'safe_edit_user_hours', '1', NULL),
(49, 'none', 'safe_edit_user_times', '10000', NULL),
(50, 'none', 'safe_edit_pwd_hours', '1', NULL),
(51, 'none', 'safe_edit_pwd_times', '30000', NULL),
(52, 'none', 'sentmail', '0', NULL),
(53, 'none', 'sentmail_smtp', '', NULL),
(54, 'none', 'sentmail_send', '', NULL),
(55, 'none', 'sentmail_password', '', NULL),
(56, 'none', 'sentmail_receive', '', NULL),
(57, 'none', 'nav_stage_header', '页头导航', NULL),
(58, 'none', 'nav_stage_footer', '页脚导航', NULL),
(59, 'none', 'nav_admin_header', '后台主导航', NULL),
(60, 'none', 'nav_admin_basic', ' 商城设置', NULL),
(61, 'none', 'nav_admin_goods', '商品管理', NULL),
(62, 'none', 'nav_admin_business', '订单管理', NULL),
(63, 'none', 'nav_admin_service', '用户互动', NULL),
(64, 'none', 'nav_admin_article', '文章管理', NULL),
(65, 'none', 'nav_admin_file', '文件管理', NULL),
(66, 'none', 'nav_admin_site', '网站设置', NULL),
(67, 'none', 'version', 'oneb2c 1.0', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
