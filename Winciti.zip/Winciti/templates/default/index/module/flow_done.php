{*<?php exit();?>*}
{if $flow_done == 1}
	<div id="flow_done">
		<div class="head">感谢您在本店购物！您的订单已Post成功，请记住您的订单号:<span>{$ord_sn}</span></div>
		<div class="main">
			<div>
				您选定的配送方式为:<span>{$ord_shipping_name}</span>，您选定的支付方式为:<span>{$ord_payment_name}</span>。您的应付款金额为:<span>￥{$ord_price_total}元</span><br />
				{$pay_text}<br />
				{if $pay_code == 'chinabank'}
				<form id="form_pay" method="post" action="{url channel='pay' dir='chinabank' file='send'}">
					<input type="hidden" name="v_oid" value="{$ord_sn}" />
					<input type="hidden" name="v_amount" value="{$ord_price_total}" />
					<input class="button" type="submit" value="进入完成支付" />
				</form>
				{/if}
				您可以&nbsp;<a href="./">返回Home</a>&nbsp;或去&nbsp;<a href="{url channel='user'}">用户中心</a>
			</div>
		</div>
	</div>
{else}
	<div class="block" id="info">
		<div class="head"><span>系统信息</span></div>
		<div class="main">
			<div>{$info_text}</div>
			<a href="{$link_href}">{$link_text}</a>
		</div>
	</div>
	<script language="javascript">
		interval = setInterval("document.location.href = '{$link_href}'",3000);
	</script>
{/if}