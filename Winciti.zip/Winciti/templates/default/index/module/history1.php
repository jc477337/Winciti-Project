{*<?php exit();?>*}
<div class="block img_list2" id="history">
	<div class="head"><span>您浏览过的商品</span></div>
	<div class="main">
		{foreach from=$history name=history item=item}
		<div class="unit">
			<div class="img">
				<table>
					<tr>
						<td>
							<a href="{url channel='goods' id=$item.goo_id}" target="_blank"><img src="{$S_ROOT}{$item.goo_x_img}" onload="picresize(this,50,50)"/></a>
						</td>
					</tr>
				</table>
			</div>
			<div class="word">
				<div class="title"><a href="" target="_blank">{$item.goo_title}</a></div>
				<div class="price">本店价:￥{$item.goo_shop_price}元</div>
			</div>
			<div class="clear"></div>
		</div>
		{/foreach}
	</div>
</div>
<!--  -->