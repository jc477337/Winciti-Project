{*<?php exit();?>*}
<div class="block" id="notice">
	<div class="head"><span>Announcement</span></div>
	<div class="main">
		{$notice}
	</div>
</div>
<!--  -->
