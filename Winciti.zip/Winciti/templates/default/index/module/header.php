{*<?php exit();?>*}
<div id="header">
	<div class="logo"><a href="./"><img src="{$S_ROOT}images/logo.png" /></a></div>
	<div class="cart">
		<a href="">您的购物车中有 {$cart_number} 件商品，总计金额 ￥{$cart_price} 元</a>
		<input class="button" type="button" onclick="document.location.href = '?/flow/'" value="settle"/>
	</div>
	<div id="nav">
		<ul>
			{foreach from=$nav name=nav item=item}
			<li><a href="{$item.men_url}" {if $item.target == 1}target="_blank"{/if}>{$item.men_name}</a></li>
			{/foreach}
		</ul>
		<div class="clear"></div>
	</div>
</div>
<!--  -->
