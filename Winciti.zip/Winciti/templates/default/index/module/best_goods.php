{*<?php exit();?>*}
<div class="block img_list" id="best_goods">
	<div class="head"><span>精品推荐</span><a href="{url channel='goods' best=1}">More&gt;&gt;</a></div>
	<div class="main">
		{foreach from=$best_goods name=best_goods item=item}
		<div class="unit">
			<div class="img">
				<table>
					<tr>
						<td>
							<a href="{url channel='goods' id=$item.goo_id}" target="_blank"><img src="{$S_ROOT}{$item.goo_x_img}" onload="picresize(this,130,130)"/></a>
						</td>
					</tr>
				</table>
			</div>
			<div class="word">
				<div class="title"><a href="{url channel='goods' id=$item.goo_id}" target="_blank">{$item.goo_title}</a></div>
				<div class="market_price">市场价:<span>￥{$item.goo_market_price}元</span></div>
				<div class="shop_price">本店价:￥{$item.goo_shop_price}元</div>
			</div>
		</div>
		{/foreach}
		<div class="clear"></div>
	</div>
</div>
<!--  -->