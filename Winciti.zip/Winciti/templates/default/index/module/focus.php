{*<?php exit();?>*}
<script type="text/javascript" src="{$S_TPL_PATH}js/jquery.min.js"></script>
<script type="text/javascript" src="{$S_TPL_PATH}js/focus.js"></script>
<div id="focus">
	<ul>
		{foreach from=$focus name=focus item=item}
		<li><a href="{$item.pic_url}" title="{$item.pic_title}" target="_blank"><img src="{$S_ROOT}{$item.pic_path}" /></a></li>
		{/foreach}
	</ul>
</div>
<!--  -->
