{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>Comments</span></div>
	<div class="main">
		<div class="mes_sheet com_sheet">
			<ul>
				{foreach from=$comment name=comment item=item}
				<li>
					<table>
						<tr>
							<td><span>{if $item.user_name}{$item.user_name}{else}Anonymous User{/if}</span>&nbsp;&nbsp;（{$item.com_add_time|date_format:"%Y-%m-%d %H:%M:%S"}）</td>
							<td width="80px">{section name=loop loop=$item.com_rank}<img src="{$S_TPL_PATH}images/star.gif" />{/section}</td>
						</tr>
						<tr>
							<td colspan="2">{$item.com_text}</td>
						</tr>
						{if $item.com_reply}
						<tr>
							<td colspan="2"><div class="reply"><span>管理员回复:</span>{$item.com_reply}</div></td>
						</tr>
						{/if}
					</table>
				</li>
				{/foreach}
			</ul>
			{if !$comment}<div class="not_found">NO Content</div>{/if}
		</div>
		{include file="module/page_link.php" page=$global.page}
		<div id="leave_word">
			<form name="form_add_comment" method="post" action="{url channel='info'}">
				<input name="cmd" type="hidden" value="add_comment"/>
				<input name="type" type="hidden" value="goods"/>
				<input name="page_id" type="hidden" value="{$global.id}"/>
				<table>
					<tr>
						<td class="l">User:</td>
						<td>{if $user_name}{$user_name}{else}Anonymous User{/if}</td>
					</tr>
					<tr>
						<td class="l">E-mail:</td>
						<td><input name="email" class="text" type="text" value="{$user_email}" /></td>
					</tr>
					<tr>
						<td class="l">Rating level:</td>
						<td>
							<input name="rank" type="radio" value="1" />{section name=loop loop=1}<img src="{$S_TPL_PATH}images/star.gif" />{/section}&nbsp;&nbsp;
							<input name="rank" type="radio" value="2" />{section name=loop loop=2}<img src="{$S_TPL_PATH}images/star.gif" />{/section}&nbsp;&nbsp;
							<input name="rank" type="radio" value="3" />{section name=loop loop=3}<img src="{$S_TPL_PATH}images/star.gif" />{/section}&nbsp;&nbsp;
							<input name="rank" type="radio" value="4" />{section name=loop loop=4}<img src="{$S_TPL_PATH}images/star.gif" />{/section}&nbsp;&nbsp;
							<input name="rank" type="radio" value="5" checked="checked" />{section name=loop loop=5}<img src="{$S_TPL_PATH}images/star.gif" />{/section}&nbsp;&nbsp;
						</td>
					</tr>
					<tr>
						<td class="l">Comments Content:</td>
						<td><textarea name="text"></textarea></td>
					</tr>
					<tr>
						<td class="bt_row" colspan="2">
							<input class="button" type="button" onclick="submit_add_comment()" value="Post" />
							<input class="button" type="reset" value="Reset"/>
						</td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
{literal}
<script language="javascript">
function submit_add_comment()
{
	var str = "";
	if(document.form_add_comment.email.value == ""){str += "-请输入您的电子邮件地址\n";}
	if(document.form_add_comment.text.value == ""){str += "-您没有输入Comments的 Content\n";}
	if(str != "")
	{
		alert(str);
	}else{
		document.form_add_comment.submit();
	}
}
</script>
{/literal}
<!--  -->