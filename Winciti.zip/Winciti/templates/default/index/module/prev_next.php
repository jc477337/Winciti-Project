{*<?php exit();?>*}
<div id="prev_next">
	<div class="prev">Previous:{if $prev_title}<a href="{url prefix=$prefix id=$prev_id}">{$prev_title}</a>{else}Nothing{/if}</div>
	<div class="next">Next:{if $next_title}<a href="{url prefix=$prefix id=$next_id}">{$next_title}</a>{else}Nothing{/if}</div>
	<div class="clear"></div>
</div>