{*<?php exit();?>*}
<div id="search">
	<form id="form_search" method="post" action="{url entrance=$global.entrance channel='search'}">
		<select name="cat">
			<option value="0">All Categories</option>
			{foreach from=$search_cat name=search_cat item=item}
			<option value="{$item.cat_id}">{$item.cat_name}</option>
			{/foreach}
		</select>
		<input class="text" name="key" type="text" maxlength="30" onkeydown="if(event.keyCode == 13)do_search();" />
		<input class="button" type="button" onclick="do_search()" value="Search" />
	</form>	
	<div class="clear"></div>
</div>
<!--  -->