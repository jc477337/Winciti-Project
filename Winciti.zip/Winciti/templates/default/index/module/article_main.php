{*<?php exit();?>*}
{if $show_sheet == 1}
	<div class="block">
		{include file="module/here.php"}
		<div class="main">
			<ul class="art_sheet">
				{foreach from=$article name=article item=item}
				<li><a href="{url channel='article' id=$item.art_id}" title="{$item.art_title}" target="_blank">{$item.art_title}</a><span>{$item.art_add_time|date_format:"%Y-%m-%d"}</span><div class="clear"></div></li>
				{/foreach}
			</ul>
			{if !$article}<div class="not_found">NO Content</div>{/if}
			{if $global.cat}{$prefix = 'article/cat-'|cat:$global.cat}{else}{$prefix = 'article'}{/if}
			{include file="module/page_link.php" page=$global.page}
		</div>
	</div>
{else}
	<div class="block">
		{include file="module/here.php"}
		<div class="main">
			<div id="article">
				<div class="title"><h3>{$article.art_title}</h3></div>
				<div class="info">
					From:{$article.art_author}&nbsp;&nbsp;&nbsp;Time:{$article.art_add_time|date_format:"%Y-%m-%d %H:%M:%S"}
				</div>
				<div class="content">{$article.art_text}</div>
				{$prefix = 'article'}
				{include file="module/prev_next.php"}
			</div>
		</div>
	</div>
{/if}
<!--  -->