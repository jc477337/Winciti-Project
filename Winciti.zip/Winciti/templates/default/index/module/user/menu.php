{*<?php exit();?>*}
<div id="user_menu">
	<ul>
		<li><a href="{url channel='user'}">欢迎页</a></li>
		<li><a href="{url channel='user' mod='profile'}">用户信息</a></li>
		<li><a href="{url channel='user' mod='order_sheet'}">我的订单</a></li>
		<li><a href="{url channel='user' mod='address_list'}">收货地址</a></li>
		<li><a href="{url channel='user' mod='collection_list'}">我的收藏</a></li>
		<li><a href="{url channel='user' mod='message_sheet'}">我的留言</a></li>
		<li><a href="{url channel='user' mod='comment_sheet'}">我的Comments</a></li>
		<li><a href="{url channel='user' mod='booking_sheet'}">缺货登记</a></li>
		<li><a href="{url channel='user' mod='account_sheet'}">在线充值</a></li>
	</ul>
	<div class="bt_row"><a href="{url channel='user' mod='logout'}">退出系统</a></div>
</div>