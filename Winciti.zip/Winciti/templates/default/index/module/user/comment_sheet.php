{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>我的Comments</span></div>
	<div class="main">
		<div class="mes_sheet">
			<ul>
				{foreach from=$comment name=comment item=item}
				<li>
					<table>
						<tr>
							<td><span>{if $item.user_name}{$item.user_name}{else}Anonymous User{/if}</span>&nbsp;&nbsp;（{$item.com_add_time|date_format:"%Y-%m-%d %H:%M:%S"}）</td>
							<td width="80px">{section name=loop loop=$item.com_rank}<img src="{$S_TPL_PATH}images/star.gif" />{/section}</td>
						</tr>
						<tr>
							<td colspan="2">{$item.com_text}</td>
						</tr>
						{if $item.com_reply}
						<tr>
							<td colspan="2"><div class="reply"><span>管理员回复:</span>{$item.com_reply}</div></td>
						</tr>
						{/if}
					</table>
				</li>
				{/foreach}
			</ul>
			{if !$comment}<div class="not_found">NO Content</div>{/if}
		</div>
		{$prefix = 'user/mod-comment_list'}
		{include file="module/page_link.php" page=$global.page}
	</div>
</div>
<!--  -->