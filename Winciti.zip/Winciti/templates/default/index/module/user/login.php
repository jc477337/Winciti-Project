{*<?php exit();?>*}
<div class="block" id="reg_login">
	<div class="head"><span>Login</span></div>
	<div class="main">
		<form name="form_user_login" method="post" action="{url channel='info'}">
			<input name="cmd" type="hidden" value="user_login"/>
			<table>
				<tr>
					<td class="l">User:</td>
					<td class="r"><input class="text" name="username" type="text" /></td>
				</tr>
				<tr>
					<td class="l">密码:</td>
					<td class="r"><input class="text" name="password" type="password" /></td>
				</tr>
				<tr>
					<td class="l"></td>
					<td>
						<input class="button" type="submit" value="登录" />&nbsp;&nbsp;
						<input class="button" type="button" value="注册" onclick="document.location.href='{url entrance=$global.entrance channel='user' mod='register'}'" />
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>