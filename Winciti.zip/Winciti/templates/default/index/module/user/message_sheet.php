{*<?php exit();?>*}
<div class="block">
	<div class="head"><span>我的留言</span></div>
	<div class="main">
		<div class="mes_sheet">
			<ul>
				{foreach from=$message name=message item=item}
				<li>
					<table>
						<tr>
							<td><b>{$item.mes_type}:</b><span>{$item.mes_title}</span>&nbsp;&nbsp;[ {$item.mes_add_time|date_format:"%Y-%m-%d %H:%M:%S"} ]</td>
						</tr>
						<tr>
							<td>{$item.mes_text}</td>
						</tr>
						{if $item.mes_reply}
						<tr>
							<td><div class="reply"><span>管理员回复:</span>{$item.mes_reply}</div></td>
						</tr>
						{/if}
					</table>
				</li>
				{/foreach}
			</ul>
			{if !$message}<div class="not_found">NO Content</div>{/if}
		</div>
		{$prefix = 'user/mod-message_sheet'}
		{include file="module/page_link.php" page=$global.page}
		<div id="leave_word">
			<form name="form_add_message" method="post" action="{url channel='user'}">
				<input name="cmd" type="hidden" value="add_message"/>
				<table>
					<tr>
						<td class="l">Message Type:</td>
						<td>
							<input name="type" type="radio" value="留言" checked="checked" />留言&nbsp;&nbsp;
							<input name="type" type="radio" value="投诉" />投诉&nbsp;&nbsp;
							<input name="type" type="radio" value="询问" />询问&nbsp;&nbsp;
							<input name="type" type="radio" value="售后" />售后&nbsp;&nbsp;
							<input name="type" type="radio" value="求购" />求购&nbsp;&nbsp;
						</td>
					</tr>
					<tr>
						<td class="l">Title:</td>
						<td><input name="title" class="text" type="text" maxlength="30"/></td>
					</tr>
					<tr>
						<td class="l">留言 Content:</td>
						<td><textarea name="text"></textarea></td>
					</tr>
					<tr>
						<td class="bt_row" colspan="2">
							<input class="button" type="button" onclick="submit_add_message()" value="Post" />
							<input class="button" type="reset" value="Reset"/>
						</td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
{literal}
<script language="javascript">
function del_message(id)
{
	if(confirm("你确实要彻底删除这条留言吗？"))
	{
		ajax("post","index.php?/user/","cmd=del_message&id=" + id,
		function(data)
		{
			if(data == 1)
			{
				document.location.replace(document.location.href);
			}
		});
	}
}
function submit_add_message()
{
	var str = "";
	if(document.form_add_message.title.value == ""){str += "-留言标题为空\n";}
	if(document.form_add_message.text.value == ""){str += "-留言 Content为空\n";}
	if(str != "")
	{
		alert(str);
	}else{
		document.form_add_message.submit();
	}
}
</script>
{/literal}
<!--  -->