{*<?php exit();?>*}
<div class="block" id="welcome">
	<div class="head"><span class="user_name">{$user_name}</span>&nbsp;&nbsp;<span>欢迎来到用户中心！</span></div>
	<div class="main">
		您的上一次登录时间:{$prev_login}<br />
		余额:￥{$user_money}元<br />
		您最近30天内Post了 <b>{$order_count}</b> 个订单<br />
	</div>
</div>
<!--  -->